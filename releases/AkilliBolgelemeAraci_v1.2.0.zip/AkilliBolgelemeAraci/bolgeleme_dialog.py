# -*- coding: utf-8 -*-
import os
import csv
import traceback
from collections import Counter

from qgis.PyQt.QtCore import Qt, QTimer, QSize, QPoint
from qgis.PyQt.QtGui import QIcon, QPixmap, QPainter, QColor, QPolygon
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QTabWidget, QWidget, QLabel, QPushButton, QSpinBox,
    QDoubleSpinBox, QCheckBox, QGroupBox, QFormLayout, QTableWidget, QTableWidgetItem,
    QHeaderView, QProgressBar, QTextEdit, QMessageBox, QAbstractItemView, QFileDialog,
    QComboBox, QApplication, QFrame, QScrollArea, QRadioButton, QButtonGroup, QSizePolicy, QLineEdit
)
from qgis.gui import QgsMapLayerComboBox, QgsFieldComboBox
from qgis.core import (
    QgsProject, QgsMapLayerProxyModel, QgsFeatureRequest,
    QgsVectorLayer, QgsRasterLayer, QgsWkbTypes
)

from . import analiz
from . import algoritma as alg

# PyQt5 / PyQt6 uyumluluk köprüsü
ScrollBarAsNeeded = getattr(Qt.ScrollBarPolicy, "ScrollBarAsNeeded", getattr(Qt, "ScrollBarAsNeeded", None))
WindowMinimizeButtonHint = getattr(Qt.WindowType, "WindowMinimizeButtonHint", getattr(Qt, "WindowMinimizeButtonHint", 0))
WindowMaximizeButtonHint = getattr(Qt.WindowType, "WindowMaximizeButtonHint", getattr(Qt, "WindowMaximizeButtonHint", 0))
PointingHandCursor = getattr(Qt.CursorShape, "PointingHandCursor", getattr(Qt, "PointingHandCursor", None))
AlignLeft = getattr(Qt.AlignmentFlag, "AlignLeft", getattr(Qt, "AlignLeft", 1))
AlignVCenter = getattr(Qt.AlignmentFlag, "AlignVCenter", getattr(Qt, "AlignVCenter", 128))
WaitCursor = getattr(Qt.CursorShape, "WaitCursor", getattr(Qt, "WaitCursor", None))

_Policy = getattr(QSizePolicy, "Policy", QSizePolicy)
PolicyExpanding = getattr(_Policy, "Expanding", getattr(QSizePolicy, "Expanding", 7))
PolicyFixed = getattr(_Policy, "Fixed", getattr(QSizePolicy, "Fixed", 0))

_ResizeMode = getattr(QHeaderView, "ResizeMode", QHeaderView)
HeaderStretch = getattr(_ResizeMode, "Stretch", getattr(QHeaderView, "Stretch", 1))

_SelectionBehavior = getattr(QAbstractItemView, "SelectionBehavior", QAbstractItemView)
SelectRows = getattr(_SelectionBehavior, "SelectRows", getattr(QAbstractItemView, "SelectRows", 1))

STYLE = """
QDialog {
    background-color: #f1f5f9;
    color: #0f172a;
    font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, Arial, sans-serif;
    font-size: 12px;
}
QScrollArea {
    border: none;
    background-color: transparent;
}
QWidget#scrollContent {
    background-color: transparent;
}
QLabel {
    color: #1e293b;
    font-size: 12px;
}
QLabel#fieldTitle {
    color: #0f172a;
    font-weight: 600;
    font-size: 12px;
}
QLabel#badgeInfo {
    background-color: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 4px;
    padding: 2px 6px;
    font-size: 11px;
    color: #475569;
}
/* Modern Kart Görünümlü QGroupBox */
QGroupBox {
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    margin-top: 12px;
    padding: 14px 12px 10px 12px;
    background-color: #ffffff;
    font-weight: 700;
    font-size: 12px;
    color: #0f172a;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 12px;
    padding: 2px 8px;
    background-color: #e0f2fe;
    color: #0369a1;
    border: 1px solid #bae6fd;
    border-radius: 4px;
}
/* Sekme (Tab) Tasarımı */
QTabWidget::pane {
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    background-color: #f8fafc;
    top: -1px;
}
QTabBar::tab {
    background-color: #e2e8f0;
    color: #475569;
    border: 1px solid #cbd5e1;
    border-bottom: none;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    padding: 8px 14px;
    margin-right: 4px;
    font-weight: 600;
    font-size: 12px;
}
QTabBar::tab:selected {
    background-color: #0284c7;
    color: #ffffff;
    border-color: #0369a1;
}
QTabBar::tab:hover:!selected {
    background-color: #ffffff;
    color: #0284c7;
}
/* 3B Dokunsal (Tactile) Butonlar */
QPushButton {
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #ffffff, stop:1 #f1f5f9);
    color: #0f172a;
    border: 1px solid #94a3b8;
    border-bottom: 2px solid #64748b;
    border-radius: 6px;
    padding: 6px 14px;
    font-weight: 600;
    font-size: 12px;
    min-height: 22px;
}
QPushButton:hover {
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #f0f9ff, stop:1 #e0f2fe);
    border-color: #0284c7;
    border-bottom: 2px solid #0369a1;
    color: #0369a1;
}
QPushButton:pressed {
    background-color: #cbd5e1;
    border: 1px solid #64748b;
    padding-top: 8px;
    padding-bottom: 4px;
}
/* Ana Çalıştır Düğmesi (Zümrüt Yeşili 3D) */
QPushButton#runBtn {
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #22c55e, stop:1 #16a34a);
    border: 1px solid #15803d;
    border-bottom: 3px solid #14532d;
    border-radius: 7px;
    color: #ffffff;
    font-size: 13px;
    font-weight: bold;
    padding: 7px 20px;
    min-height: 24px;
}
QPushButton#runBtn:hover {
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #4ade80, stop:1 #16a34a);
    border-color: #166534;
    border-bottom: 3px solid #052e16;
}
QPushButton#runBtn:pressed {
    background-color: #15803d;
    border-bottom: 1px solid #14532d;
    padding-top: 9px;
    padding-bottom: 5px;
}
QPushButton#runBtn:disabled {
    background-color: #94a3b8;
    border-color: #64748b;
    color: #e2e8f0;
}
/* CSV Dışa Aktar Düğmesi (Kurumsal Mavi 3D) */
QPushButton#exportBtn {
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #0284c7, stop:1 #0369a1);
    border: 1px solid #075985;
    border-bottom: 3px solid #0c4a6e;
    border-radius: 7px;
    color: #ffffff;
    font-size: 12px;
    font-weight: bold;
    padding: 7px 16px;
    min-height: 24px;
}
QPushButton#exportBtn:hover {
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #38bdf8, stop:1 #0284c7);
}
QPushButton#exportBtn:pressed {
    background-color: #075985;
    border-bottom: 1px solid #0c4a6e;
    padding-top: 9px;
    padding-bottom: 5px;
}
QPushButton#exportBtn:disabled {
    background-color: #e2e8f0;
    border-color: #cbd5e1;
    color: #94a3b8;
}
/* Analiz İzleme Matrisi Düğmesi (Teal / Zümrüt Yeşili 3D) */
QPushButton#matrixBtn {
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #0f766e, stop:1 #115e59);
    border: 1px solid #14b8a6;
    border-bottom: 3px solid #134e4a;
    border-radius: 7px;
    color: #ffffff;
    font-weight: 700;
    font-size: 12px;
    padding: 8px 16px;
    min-height: 24px;
}
QPushButton#matrixBtn:hover {
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #14b8a6, stop:1 #0f766e);
}
QPushButton#matrixBtn:pressed {
    background-color: #134e4a;
    border-bottom: 1px solid #134e4a;
    padding-top: 9px;
    padding-bottom: 5px;
}
QPushButton#matrixBtn:disabled {
    background-color: #e2e8f0;
    border-color: #cbd5e1;
    color: #94a3b8;
}
/* Metodoloji ve Kullanım El Kitabı Düğmesi (Cyan / Gökyüzü Mavisi 3D) */
QPushButton#helpBtn {
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #0284c7, stop:1 #0369a1);
    border: 1px solid #38bdf8;
    border-bottom: 2px solid #075985;
    border-radius: 6px;
    color: #ffffff;
    font-weight: 700;
    font-size: 12px;
    padding: 6px 14px;
    min-height: 22px;
}
QPushButton#helpBtn:hover {
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #38bdf8, stop:1 #0284c7);
    border-color: #7dd3fc;
    color: #ffffff;
}
QPushButton#helpBtn:pressed {
    background-color: #075985;
    border-bottom: 1px solid #075985;
    padding-top: 7px;
    padding-bottom: 5px;
}
/* Girdi Kutuları (Basıklığı önleyen ferah min-height) */
QComboBox, QSpinBox, QDoubleSpinBox {
    background-color: #ffffff;
    color: #0f172a;
    border: 1px solid #94a3b8;
    border-radius: 5px;
    padding: 4px 8px;
    min-height: 24px;
    font-size: 12px;
    selection-background-color: #0284c7;
    selection-color: #ffffff;
}
QComboBox:hover, QSpinBox:hover, QDoubleSpinBox:hover {
    border-color: #0284c7;
    background-color: #f8fafc;
}
QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {
    border: 1.5px solid #0284c7;
    background-color: #ffffff;
}
QComboBox QAbstractItemView {
    background-color: #ffffff;
    color: #0f172a;
    border: 1px solid #0284c7;
    selection-background-color: #0284c7;
    selection-color: #ffffff;
    outline: 0px;
}
/* Tablo Tasarımı */
QTableWidget {
    background-color: #ffffff;
    alternate-background-color: #f8fafc;
    color: #0f172a;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    gridline-color: #e2e8f0;
    selection-background-color: #e0f2fe;
    selection-color: #0369a1;
}
QHeaderView::section {
    background-color: #f1f5f9;
    color: #0f172a;
    padding: 6px 8px;
    border: none;
    border-right: 1px solid #cbd5e1;
    border-bottom: 1px solid #cbd5e1;
    font-weight: 700;
}
QCheckBox, QRadioButton {
    color: #1e293b;
    font-weight: 500;
    spacing: 8px;
    padding: 2px 0px;
}
QProgressBar {
    border: 1px solid #94a3b8;
    border-radius: 6px;
    background-color: #e2e8f0;
    text-align: center;
    color: #0f172a;
    font-weight: bold;
    min-height: 24px;
    max-height: 24px;
}
QProgressBar::chunk {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0284c7, stop:1 #22c55e);
    border-radius: 5px;
}
QTextEdit {
    background-color: #ffffff;
    color: #0f172a;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 6px;
    font-family: 'Segoe UI', Consolas, monospace;
    font-size: 12px;
}
"""

FIELD_DEFS = [
    ("kullanim", "Arazi / Yapı Kullanımı", ("kullanim", "fonksiyon", "landuse", "arazi", "amac", "sinif", "tur", "cins", "nitelik", "islev", "mk"), False),
    ("kat", "Kat Adedi / Yüksekliği", ("kat", "floor", "yukseklik", "height", "ks", "kat_adedi", "katsayisi"), True),
    ("yd", "Yapı Nizamı (Bitişik/Ayrık)", ("nizam", "duzen", "yd", "yapilasma", "terti"), False),
    ("durum", "Yapı Fiziksel Durumu", ("durum", "kalite", "fiziksel", "yf", "hasar", "yapi_durum"), False),
    ("nufus", "Nüfus / Kişi Sayısı Sütunu", ("nufus", "pop", "kisi", "sn", "hane"), True),
]

BLDG_FIELD_DEFS = [
    ("kullanim", "Yapı Fonksiyonu / Türü", ("kullanim", "fonksiyon", "tur", "cins", "nitelik", "islev", "sinif"), False),
    ("kat", "Yapı Kat Adedi", ("kat", "floor", "yukseklik", "height", "ks", "kat_adedi", "katsayisi"), True),
    ("yd", "Yapı Nizamı (Bitişik/Ayrık)", ("nizam", "duzen", "yd", "yapilasma"), False),
    ("durum", "Yapı Fiziksel Durumu", ("durum", "kalite", "fiziksel", "yf", "hasar"), False),
    ("nufus", "Yapı Nüfusu / Kişi Sayısı", ("nufus", "pop", "kisi", "sn", "hane"), True),
]

ROAD_FIELD_DEFS = [
    ("r_genislik", "Yol Genişliği (Metre)", ("genislik", "width", "yg", "en", "cap", "serit"), True),
    ("r_kaplama", "Üstyapı / Kaplama Türü", ("kaplama", "yuzey", "zemin", "surface", "malzeme", "cins"), False),
    ("r_tur", "Yol Kademelenmesi", ("kademe", "tur", "sinif", "type", "class", "statu", "nitelik", "yol_turu"), False),
]

NATURAL_LAYER_RULES = [
    ("dere", "Dere / Akarsu Yatağı", ("dere", "akarsu", "nehir", "cay", "su_yolu", "kanal", "vadisi", "hidroloji")),
    ("fay", "Diri Fay Hattı", ("fay", "fault", "deprem", "diri_fay", "kiri")),
    ("sit", "Sit / Koruma Alanı", ("sit", "koruma", "tescil", "arkeoloji", "kentsel_sit", "dogal_sit", "anit")),
    ("risk", "Taşkın / Afet Risk Alanı", ("taskin", "sel", "risk", "heyelan", "afete_maruz", "sakincali", "jeoloji")),
    ("donati", "Sosyal ve Teknik Donatı", ("donati", "okul", "egitim", "park", "yesil", "cami", "resmi", "sosyal", "kult", "spor")),
    ("toplanma", "Afet Toplanma Alanı", ("toplanma", "acil_toplanma")),
    ("saglik", "Sağlık Tesisi", ("saglik", "hastane", "asm", "poliklinik")),
    ("syntax", "Space Syntax (NAIN/NACH)", ("syntax", "nain", "nach", "entegrasyon", "choice", "integration", "erisim")),
    ("donati_erisim", "2SFCA Donatı Erişimi / Aşırı Yükleme", ("2sfca", "fca", "overload", "erisim_acigi", "donati_baski")),
    ("lst", "Kentsel Isı Adası / LST", ("lst", "isi_adasi", "thermal", "sicaklik", "termal", "heat")),
    ("tarim", "Tarım / Ova Alanı", ("tarim", "ova", "buyukova", "mera", "ziraat")),
    ("sanayi", "Sanayi / OSB Alanı", ("sanayi", "osb", "endustri", "depolama", "kss")),
]


def wrap_in_scroll(widget):
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    if ScrollBarAsNeeded is not None:
        scroll.setHorizontalScrollBarPolicy(ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(ScrollBarAsNeeded)
    widget.setObjectName("scrollContent")
    scroll.setWidget(widget)
    return scroll


def create_flag_icon(lang_code):
    pix = QPixmap(24, 16)
    pix.fill(QColor(0, 0, 0, 0))
    p = QPainter(pix)
    aa_hint = getattr(getattr(QPainter, "RenderHint", QPainter), "Antialiasing", 1)
    p.setRenderHint(aa_hint)
    no_pen = getattr(getattr(Qt, "PenStyle", Qt), "NoPen", 0)
    p.setPen(no_pen)
    if lang_code == "tr":
        p.setBrush(QColor("#E30A17"))
        p.drawRoundedRect(0, 0, 24, 16, 2, 2)
        p.setBrush(QColor("#FFFFFF"))
        p.drawEllipse(6, 4, 8, 8)
        p.setBrush(QColor("#E30A17"))
        p.drawEllipse(8, 5, 6, 6)
        p.setBrush(QColor("#FFFFFF"))
        p.drawPolygon(QPolygon([QPoint(14, 8), QPoint(17, 6), QPoint(16, 9), QPoint(18, 9), QPoint(15, 10)]))
    elif lang_code == "en":
        p.setBrush(QColor("#012169"))
        p.drawRoundedRect(0, 0, 24, 16, 2, 2)
        p.setBrush(QColor("#FFFFFF"))
        p.drawRect(10, 0, 4, 16)
        p.drawRect(0, 6, 24, 4)
        p.setBrush(QColor("#C8102E"))
        p.drawRect(11, 0, 2, 16)
        p.drawRect(0, 7, 24, 2)
    elif lang_code == "zh":
        p.setBrush(QColor("#EE1C25"))
        p.drawRoundedRect(0, 0, 24, 16, 2, 2)
        p.setBrush(QColor("#FFFF00"))
        p.drawEllipse(3, 3, 5, 5)
        for sx, sy in [(9, 2), (11, 4), (11, 7), (9, 9)]:
            p.drawEllipse(sx, sy, 2, 2)
    elif lang_code == "es":
        p.setBrush(QColor("#AA151B"))
        p.drawRoundedRect(0, 0, 24, 16, 2, 2)
        p.setBrush(QColor("#F1BF00"))
        p.drawRect(0, 4, 24, 8)
    p.end()
    return QIcon(pix)


UI_TRANSLATIONS = {
    "tr": {
        "win_title": "Kentsel Bölgeleme ve Kırılganlık Analiz Aracı — Baran Adsuna",
        "hdr_title": "Kentsel Bölgeleme ve Kırılganlık Analiz Aracı",
        "hdr_sub": "⚡ Geliştirici / Yazar: Baran Adsuna  •  MPYY Uyumlu Morfolojik Bölgeleme, Çok Kriterli Sentez ve Karar Destek Sistemi",
        "lbl_mode": "Analiz Derinliği & Mod:",
        "mode_std": "🌱 Standart Bölgeleme Modu (MPYY Morfolojik Alt Bölgeler - Hızlı & Pratik)",
        "mode_adv": "🔬 İleri Sentez & Müdahale Atlası Modu (Kırılganlık [E/S/AC], Rakım, Müdahale Kararları & Plan Karşılığı)",
        "badge_adv": "🔬 <b>İleri Sentez & Müdahale Atlası Aktif:</b> M1..M28 kodları, 3B Kırılganlık (E·S/AC), DEM Rakım (Z), Müdahale Kararları, 1/5000 & 1/1000 Plan Karşılıkları ve Analiz İzleme Matrisi üretilir.",
        "badge_std": "🌱 <b>Standart Bölgeleme Modu Aktif:</b> A1..A28 morfolojik profil eşleşmesi, doku homojenliği ve sınır ayrım gerekçeleri üretilir (Hızlı ön bölgeleme).",
        "btn_help": "📖 Metodoloji ve Kullanım El Kitabı (HTML)",
        "btn_top_adv": "▶ İleri Sentez Başlat",
        "btn_top_std": "▶ Standart Bölgele",
        "tab_1": "1. Katmanlar, Yapılar ve Nüfus",
        "tab_2": "2. Doğal Eşikler ve DEM",
        "tab_3": "3. Ağırlıklar ve Ayarlar",
        "tab_4": "4. Sınır Ayrım Gerekçeleri Raporu",
        "tab_5": "5. Metodoloji ve MPYY Kılavuzu",
        "btn_quick_csv": "⚡ Hızlı Özet (Sade CSV)",
        "btn_csv": "📊 Detaylı Tablo (CSV)",
        "btn_matrix": "📋 İzleme Matrisi (CSV)",
        "btn_run_adv": "▶ ÇALIŞTIR — İLERİ SENTEZ (M1..M28)",
        "btn_run_std": "▶ ÇALIŞTIR — STANDART BÖLGELEME (A1..A28)",
        "view_lbl": "Görünüm Modu:",
        "rb_quick": "⚡ Hızlı ve Sade Özet (Hızlı Okuma)",
        "rb_both": "📋 İkisi Bir Arada (Özet + Detay)",
        "rb_detailed": "🔬 Sadece Detaylı Teknik (ΔZ & Kodlar)",
        "filter_ph": "🔍 Bölge kodu veya anahtar kelime filtrele (ör: M26, Konut, Fay, Donatı, Sit)...",
        "chk_quick_layer": "Haritaya ayrıca sadeleştirilmiş 'Alt_Bolgeler_Hizli_Ozet' katmanı ekle (Sadece hızlı okuma sütunları)",
    },
    "en": {
        "win_title": "Urban Zoning & Vulnerability Analyzer — Baran Adsuna",
        "hdr_title": "Urban Zoning & Vulnerability Analysis Tool",
        "hdr_sub": "⚡ Author / Developer: Baran Adsuna  •  MPYY Morphological Zoning, Multi-Criteria Synthesis & Decision Support",
        "lbl_mode": "Analysis Depth / Mode:",
        "mode_std": "🌱 Standard Zoning Mode (MPYY Morphological Sub-Zones - Fast & Practical)",
        "mode_adv": "🔬 Advanced Synthesis & Intervention Atlas Mode (Vulnerability [E/S/AC], Elevation, Decisions & Plan Map)",
        "badge_adv": "🔬 <b>Advanced Synthesis & Intervention Atlas Active:</b> Generates M1..M28 codes, 3D Vulnerability (E·S/AC), DEM Elevation (Z), Intervention Decisions, 1/5000 & 1/1000 Plan Rules, and Tracking Matrix.",
        "badge_std": "🌱 <b>Standard Zoning Mode Active:</b> Generates A1..A28 morphological profile matching, fabric homogeneity, and boundary separation rationales.",
        "btn_help": "📖 Methodology & User Guide (HTML)",
        "btn_top_adv": "▶ Run Synthesis",
        "btn_top_std": "▶ Run Standard",
        "tab_1": "1. Layers, Buildings & Pop.",
        "tab_2": "2. Natural Thresholds & DEM",
        "tab_3": "3. Weights & Settings",
        "tab_4": "4. Boundary Rationales Report",
        "tab_5": "5. Methodology & MPYY Guide",
        "btn_quick_csv": "⚡ Quick Summary (CSV)",
        "btn_csv": "📊 Detailed Table (CSV)",
        "btn_matrix": "📋 Tracking Matrix (CSV)",
        "btn_run_adv": "▶ RUN — ADVANCED SYNTHESIS (M1..M28)",
        "btn_run_std": "▶ RUN — STANDARD ZONING (A1..A28)",
        "view_lbl": "View Mode:",
        "rb_quick": "⚡ Quick & Plain Summary (Fast Read)",
        "rb_both": "📋 Combined (Quick + Detailed)",
        "rb_detailed": "🔬 Detailed Technical Only (ΔZ & Codes)",
        "filter_ph": "🔍 Filter by zone code or keyword (e.g. M26, Konut, Fay, Donatı, Sit)...",
        "chk_quick_layer": "Also add simplified 'Alt_Bolgeler_Hizli_Ozet' layer to map (Quick-reading columns only)",
    },
    "zh": {
        "win_title": "城市分区与脆弱性分析工具 — Baran Adsuna",
        "hdr_title": "城市形态分区与多准则脆弱性分析系统",
        "hdr_sub": "⚡ 开发者 / 作者: Baran Adsuna  •  MPYY 形态分区、多准则综合与空间决策支持系统",
        "lbl_mode": "分析深度与模式:",
        "mode_std": "🌱 标准分区模式 (MPYY 形态子分区 - 快速实用)",
        "mode_adv": "🔬 高级综合与干预图集模式 (脆弱性 [E/S/AC]、高程、干预决策与规划对应)",
        "badge_adv": "🔬 <b>高级综合与干预图集已启用:</b> 生成 M1..M28 编码、三维脆弱性 (E·S/AC)、DEM高程、干预决策与分析追踪矩阵。",
        "badge_std": "🌱 <b>标准分区模式已启用:</b> 生成 A1..A28 形态轮廓匹配、肌理同质性与边界划分依据。",
        "btn_help": "📖 方法论与用户手册 (HTML)",
        "btn_top_adv": "▶ 启动高级综合",
        "btn_top_std": "▶ 启动标准分区",
        "tab_1": "1. 图层、建筑与人口",
        "tab_2": "2. 自然阈值与 DEM",
        "tab_3": "3. 权重与参数设置",
        "tab_4": "4. 边界划分依据与报告",
        "tab_5": "5. 方法论与 MPYY 指南",
        "btn_quick_csv": "⚡ 快速摘要表 (简明 CSV)",
        "btn_csv": "📊 完整分区表 (详细 CSV)",
        "btn_matrix": "📋 分析追踪矩阵 (CSV)",
        "btn_run_adv": "▶ 运行 — 高级综合与干预图集 (M1..M28)",
        "btn_run_std": "▶ 运行 — 标准形态分区 (A1..A28)",
        "view_lbl": "视图模式:",
        "rb_quick": "⚡ 快速简明摘要 (快速阅读)",
        "rb_both": "📋 双重对照 (快速摘要 + 详细数据)",
        "rb_detailed": "🔬 仅详细技术验证 (ΔZ 与代码)",
        "filter_ph": "🔍 按分区代码或关键词筛选 (例如: M26, Konut, Fay)...",
        "chk_quick_layer": "同时在地图中添加精简版 'Alt_Bolgeler_Hizli_Ozet' 图层 (仅包含快速阅读列)",
    },
    "es": {
        "win_title": "Herramienta de Zonificación Urbana y Vulnerabilidad — Baran Adsuna",
        "hdr_title": "Analizador de Zonificación Morfológica y Vulnerabilidad Urbana",
        "hdr_sub": "⚡ Desarrollador / Autor: Baran Adsuna  •  Zonificación Morfológica MPYY y Soporte de Decisiones",
        "lbl_mode": "Modo y Profundidad:",
        "mode_std": "🌱 Modo de Zonificación Estándar (Subzonas Morfológicas MPYY - Rápido y Práctico)",
        "mode_adv": "🔬 Modo de Síntesis Avanzada y Atlas de Intervención (Vulnerabilidad [E/S/AC], Elevación y Plan)",
        "badge_adv": "🔬 <b>Síntesis Avanzada Activa:</b> Genera códigos M1..M28, Vulnerabilidad 3D (E·S/AC), Elevación DEM, Decisiones de Intervención y Matriz de Seguimiento.",
        "badge_std": "🌱 <b>Modo Estándar Activo:</b> Genera perfiles A1..A28, homogeneidad morfológica y justificación de límites.",
        "btn_help": "📖 Metodología y Manual (HTML)",
        "btn_top_adv": "▶ Iniciar Síntesis",
        "btn_top_std": "▶ Zonificar",
        "tab_1": "1. Capas, Edificios y Pob.",
        "tab_2": "2. Umbrales Naturales y DEM",
        "tab_3": "3. Pesos y Ajustes",
        "tab_4": "4. Justificación de Límites y Reporte",
        "tab_5": "5. Metodología y Guía MPYY",
        "btn_quick_csv": "⚡ Resumen Rápido (CSV Simple)",
        "btn_csv": "📊 Tabla Completa (CSV Detallado)",
        "btn_matrix": "📋 Matriz de Seguimiento (CSV)",
        "btn_run_adv": "▶ EJECUTAR — SÍNTESIS AVANZADA Y ATLAS DE INTERVENCIÓN (M1..M28)",
        "btn_run_std": "▶ EJECUTAR — ZONIFICACIÓN MORFOLÓGICA ESTÁNDAR (A1..A28)",
        "view_lbl": "Vista:",
        "rb_quick": "⚡ Resumen Rápido (Lectura Simple)",
        "rb_both": "📋 Vista Combinada (Resumen + Detalle)",
        "rb_detailed": "🔬 Solo Técnico Detallado (ΔZ y Códigos)",
        "filter_ph": "🔍 Filtrar por código de zona o palabra clave (ej: M26, Konut, Fay)...",
        "chk_quick_layer": "Añadir también capa simplificada 'Alt_Bolgeler_Hizli_Ozet' al mapa (Solo columnas rápidas)",
    },
}


class BolgelemeDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        icon_path = os.path.join(self.plugin_dir, "icon.svg")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
        self.setWindowTitle("Kentsel Bölgeleme ve Kırılganlık Analiz Aracı — Baran Adsuna")
        flags = self.windowFlags()
        if WindowMinimizeButtonHint:
            flags |= WindowMinimizeButtonHint
        if WindowMaximizeButtonHint:
            flags |= WindowMaximizeButtonHint
        self.setWindowFlags(flags)
        self.setMinimumSize(780, 500)
        self.setStyleSheet(STYLE)
        self.records = []
        self.quick_records = []
        self._pipeline_logs = []
        self.last_zones = []
        self.current_lang = "tr"
        self._sample_cache = {}
        self.build_ui()
        self.fit_to_screen()

    def fit_to_screen(self):
        try:
            screen = QApplication.primaryScreen()
            if self.iface and hasattr(self.iface, "mainWindow") and self.iface.mainWindow() and hasattr(self.iface.mainWindow(), "screen") and self.iface.mainWindow().screen():
                screen = self.iface.mainWindow().screen()
            if screen:
                avail = screen.availableGeometry()
                w = min(920, int(avail.width() * 0.78))
                h = min(680, int(avail.height() * 0.78))
                self.resize(max(780, w), max(500, h))
                x = avail.x() + (avail.width() - self.width()) // 2
                y = avail.y() + (avail.height() - self.height()) // 2
                self.move(max(avail.x(), x), max(avail.y() + 10, y))
            else:
                self.resize(880, 620)
        except (AttributeError, RuntimeError):
            self.resize(880, 620)

    # ------------------------------------------------------------ arayüz
    def build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 10, 12, 10)
        root.setSpacing(8)

        # Üst Başlık Kartı (3D İkon + Başlık + Hızlı Çalıştır Düğmesi)
        hdr = QFrame()
        hdr.setStyleSheet(
            "QFrame { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0f172a, stop:0.6 #1e293b, stop:1 #0f172a); "
            "border: 1px solid #334155; border-radius: 8px; padding: 6px 12px; }"
        )
        h_lay = QHBoxLayout(hdr)
        h_lay.setContentsMargins(8, 6, 8, 6)
        h_lay.setSpacing(12)

        # 3D İkon Gösterimi
        icon_lbl = QLabel()
        icon_path = os.path.join(self.plugin_dir, "icon.svg")
        if os.path.exists(icon_path):
            pix = QIcon(icon_path).pixmap(QSize(50, 50))
            icon_lbl.setPixmap(pix)
        icon_lbl.setFixedSize(52, 52)
        icon_lbl.setStyleSheet("border: none; background: transparent;")
        h_lay.addWidget(icon_lbl)

        t_box = QVBoxLayout()
        t_box.setSpacing(3)
        self.lbl_hdr_title = QLabel("Kentsel Bölgeleme ve Kırılganlık Analiz Aracı")
        self.lbl_hdr_title.setStyleSheet("font-size: 14px; font-weight: bold; color: #f8fafc; border: none; background: transparent;")
        self.lbl_hdr_sub = QLabel("⚡ Geliştirici / Yazar: Baran Adsuna  •  MPYY Uyumlu Morfolojik Bölgeleme, Çok Kriterli Sentez ve Karar Destek Sistemi")
        self.lbl_hdr_sub.setStyleSheet("color: #38bdf8; font-size: 11px; font-weight: 600; border: none; background: transparent;")
        t_box.addWidget(self.lbl_hdr_title)
        t_box.addWidget(self.lbl_hdr_sub)

        mode_box = QHBoxLayout()
        mode_box.setSpacing(8)
        self.lbl_mode_title = QLabel("Analiz Derinliği & Mod:")
        self.lbl_mode_title.setStyleSheet("color: #38bdf8; font-weight: bold; font-size: 11px; border: none; background: transparent;")
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItem("🌱 Standart Bölgeleme Modu (MPYY Morfolojik Alt Bölgeler - Hızlı & Pratik)", "standard")
        self.cmb_mode.addItem("🔬 İleri Sentez & Müdahale Atlası Modu (Kırılganlık [E/S/AC], Rakım, Müdahale Kararları & Plan Karşılığı)", "advanced")
        self.cmb_mode.setCurrentIndex(1)
        self.cmb_mode.setStyleSheet("QComboBox { background-color: #1e293b; color: #f8fafc; border: 1px solid #475569; border-radius: 4px; padding: 2px 8px; font-size: 11px; font-weight: 600; }")
        mode_box.addWidget(self.lbl_mode_title)
        mode_box.addWidget(self.cmb_mode, 1)
        t_box.addLayout(mode_box)

        self.lbl_mode_badge = QLabel()
        self.lbl_mode_badge.setWordWrap(True)
        t_box.addWidget(self.lbl_mode_badge)

        # Dil Seçici (Türkçe, English, 中文, Español)
        self.cmb_lang = QComboBox()
        self.cmb_lang.setIconSize(QSize(20, 14))
        self.cmb_lang.addItem(create_flag_icon("tr"), "Türkçe (TR)", "tr")
        self.cmb_lang.addItem(create_flag_icon("en"), "English (EN)", "en")
        self.cmb_lang.addItem(create_flag_icon("zh"), "中文 (ZH)", "zh")
        self.cmb_lang.addItem(create_flag_icon("es"), "Español (ES)", "es")
        self.cmb_lang.setMinimumWidth(130)
        self.cmb_lang.setStyleSheet(
            "QComboBox { background-color: #1e293b; color: #f8fafc; border: 1px solid #38bdf8; "
            "border-radius: 6px; padding: 4px 8px; font-weight: bold; font-size: 11px; }"
        )
        self.cmb_lang.currentIndexChanged.connect(lambda _: self.set_language(self.cmb_lang.currentData()))

        self.btn_help = QPushButton("📖 Metodoloji ve Kullanım El Kitabı (HTML)")
        self.btn_help.setObjectName("helpBtn")
        if PointingHandCursor is not None:
            self.btn_help.setCursor(PointingHandCursor)
        self.btn_help.clicked.connect(self.open_html_guide)

        self.btn_top_run = QPushButton("▶ Hemen Çalıştır")
        self.btn_top_run.setObjectName("runBtn")
        if PointingHandCursor is not None:
            self.btn_top_run.setCursor(PointingHandCursor)
        self.btn_top_run.clicked.connect(self.run)

        right_hdr_col = QVBoxLayout()
        right_hdr_col.setSpacing(6)
        top_btn_row = QHBoxLayout()
        top_btn_row.setSpacing(6)
        top_btn_row.addWidget(self.cmb_lang)
        top_btn_row.addWidget(self.btn_help)
        right_hdr_col.addLayout(top_btn_row)
        right_hdr_col.addWidget(self.btn_top_run)

        h_lay.addLayout(t_box, 1)
        h_lay.addLayout(right_hdr_col)
        root.addWidget(hdr)

        # Sekmeler
        self.tabs = QTabWidget()
        self.tabs.addTab(wrap_in_scroll(self.page_layers()), "1. Katmanlar, Yapılar ve Nüfus")
        self.tabs.addTab(wrap_in_scroll(self.page_extra()), "2. Doğal Eşikler ve DEM")
        self.tabs.addTab(wrap_in_scroll(self.page_settings()), "3. Ağırlıklar ve Ayarlar")
        self.tabs.addTab(self.page_results(), "4. Sınır Ayrım Gerekçeleri Raporu")
        self.tabs.addTab(self.page_about(), "5. Metodoloji ve MPYY Kılavuzu")
        root.addWidget(self.tabs, 1)

        # Sabit Alt Çalıştırma Çubuğu
        bot_frame = QFrame()
        bot_frame.setStyleSheet(
            "QFrame { background-color: #ffffff; border: 1px solid #cbd5e1; border-radius: 8px; padding: 4px; }"
        )
        bot = QHBoxLayout(bot_frame)
        bot.setContentsMargins(10, 6, 10, 6)
        bot.setSpacing(8)

        self.progress = QProgressBar()
        self.progress.setValue(0)

        self.btn_quick_csv = QPushButton("⚡ Hızlı Özet (Sade CSV)")
        self.btn_quick_csv.setObjectName("exportBtn")
        if PointingHandCursor is not None:
            self.btn_quick_csv.setCursor(PointingHandCursor)
        self.btn_quick_csv.setEnabled(False)
        self.btn_quick_csv.clicked.connect(self.export_quick_csv)

        self.btn_csv = QPushButton("📊 Detaylı Tablo (CSV)")
        self.btn_csv.setObjectName("exportBtn")
        if PointingHandCursor is not None:
            self.btn_csv.setCursor(PointingHandCursor)
        self.btn_csv.setEnabled(False)
        self.btn_csv.clicked.connect(self.export_csv)

        self.btn_matrix = QPushButton("📋 İzleme Matrisi (CSV)")
        self.btn_matrix.setObjectName("matrixBtn")
        if PointingHandCursor is not None:
            self.btn_matrix.setCursor(PointingHandCursor)
        self.btn_matrix.setEnabled(False)
        self.btn_matrix.clicked.connect(self.export_analysis_matrix)

        self.btn_run = QPushButton("▶ ÇALIŞTIR — İLERİ SENTEZ (M1..M28)")
        self.btn_run.setObjectName("runBtn")
        if PointingHandCursor is not None:
            self.btn_run.setCursor(PointingHandCursor)
        self.btn_run.clicked.connect(self.run)

        bot.addWidget(self.progress, 1)
        bot.addWidget(self.btn_quick_csv)
        bot.addWidget(self.btn_csv)
        bot.addWidget(self.btn_matrix)
        bot.addWidget(self.btn_run)
        root.addWidget(bot_frame)

        self.cmb_mode.currentIndexChanged.connect(self._on_mode_changed)
        self._on_mode_changed()

    def set_language(self, lang_code):
        if lang_code not in UI_TRANSLATIONS:
            lang_code = "tr"
        self.current_lang = lang_code
        tr = UI_TRANSLATIONS[lang_code]
        self.setWindowTitle(tr["win_title"])
        if hasattr(self, "lbl_hdr_title"):
            self.lbl_hdr_title.setText(tr["hdr_title"])
        if hasattr(self, "lbl_hdr_sub"):
            self.lbl_hdr_sub.setText(tr["hdr_sub"])
        if hasattr(self, "lbl_mode_title"):
            self.lbl_mode_title.setText(tr["lbl_mode"])
        if hasattr(self, "cmb_mode"):
            self.cmb_mode.blockSignals(True)
            self.cmb_mode.setItemText(0, tr["mode_std"])
            self.cmb_mode.setItemText(1, tr["mode_adv"])
            self.cmb_mode.blockSignals(False)
        if hasattr(self, "btn_help"):
            self.btn_help.setText(tr["btn_help"])
        if hasattr(self, "tabs"):
            for idx, key in enumerate(("tab_1", "tab_2", "tab_3", "tab_4", "tab_5")):
                self.tabs.setTabText(idx, tr[key])
        if hasattr(self, "btn_quick_csv"):
            self.btn_quick_csv.setText(tr["btn_quick_csv"])
        if hasattr(self, "btn_csv"):
            self.btn_csv.setText(tr["btn_csv"])
        if hasattr(self, "btn_matrix"):
            self.btn_matrix.setText(tr["btn_matrix"])
        if hasattr(self, "lbl_view_mode"):
            self.lbl_view_mode.setText(f"<b>{tr['view_lbl']}</b>")
        if hasattr(self, "rb_view_quick"):
            self.rb_view_quick.setText(tr["rb_quick"])
        if hasattr(self, "rb_view_both"):
            self.rb_view_both.setText(tr["rb_both"])
        if hasattr(self, "rb_view_detailed"):
            self.rb_view_detailed.setText(tr["rb_detailed"])
        if hasattr(self, "txt_filter"):
            self.txt_filter.setPlaceholderText(tr["filter_ph"])
        if hasattr(self, "chk_quick_layer"):
            self.chk_quick_layer.setText(tr["chk_quick_layer"])
        self._on_mode_changed()

    def _on_mode_changed(self):
        """Kullanıcı analiz modunu değiştirdiğinde arayüzü, rozeti ve butonları dinamik günceller."""
        tr = UI_TRANSLATIONS.get(getattr(self, "current_lang", "tr"), UI_TRANSLATIONS["tr"])
        is_adv = (self.cmb_mode.currentData() == "advanced") if hasattr(self, "cmb_mode") else True
        if is_adv:
            if hasattr(self, "lbl_mode_badge"):
                self.lbl_mode_badge.setText(tr["badge_adv"])
                self.lbl_mode_badge.setStyleSheet(
                    "color: #bae6fd; font-size: 11px; background: rgba(56, 189, 248, 0.12); "
                    "padding: 5px 8px; border-radius: 4px; border: 1px solid rgba(56, 189, 248, 0.4);"
                )
            if hasattr(self, "btn_run"):
                self.btn_run.setText(tr["btn_run_adv"])
            if hasattr(self, "btn_top_run"):
                self.btn_top_run.setText(tr["btn_top_adv"])
            if hasattr(self, "btn_matrix"):
                self.btn_matrix.setVisible(True)
        else:
            if hasattr(self, "lbl_mode_badge"):
                self.lbl_mode_badge.setText(tr["badge_std"])
                self.lbl_mode_badge.setStyleSheet(
                    "color: #bbf7d0; font-size: 11px; background: rgba(34, 197, 94, 0.12); "
                    "padding: 5px 8px; border-radius: 4px; border: 1px solid rgba(34, 197, 94, 0.4);"
                )
            if hasattr(self, "btn_run"):
                self.btn_run.setText(tr["btn_run_std"])
            if hasattr(self, "btn_top_run"):
                self.btn_top_run.setText(tr["btn_top_std"])
            if hasattr(self, "btn_matrix"):
                self.btn_matrix.setVisible(False)

    def _make_field_row_widget(self, combo, info_label):
        """Açılır kutu ve önizleme rozetini sıkışmadan ferah biçimde hizalayan yardımcı kapsayıcı."""
        row_w = QWidget()
        row_l = QVBoxLayout(row_w)
        row_l.setContentsMargins(0, 2, 0, 4)
        row_l.setSpacing(4)
        combo.setSizePolicy(PolicyExpanding, PolicyFixed)
        info_label.setObjectName("badgeInfo")
        info_label.setWordWrap(True)
        row_l.addWidget(combo)
        row_l.addWidget(info_label)
        return row_w

    # ------------------------------------------------------------ 1. Sekme: Ana Katmanlar + Opsiyonel Yapılar + Nüfus
    def page_layers(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(10, 8, 10, 10)
        lay.setSpacing(10)

        # A. Ana Katmanlar
        g = QGroupBox("A. Ana Planlama Katmanları")
        f = QFormLayout(g)
        f.setContentsMargins(12, 10, 12, 10)
        f.setHorizontalSpacing(14)
        f.setVerticalSpacing(8)
        f.setLabelAlignment(AlignLeft | AlignVCenter)

        self.cmb_boundary = QgsMapLayerComboBox()
        self.cmb_boundary.setAllowEmptyLayer(True)
        self.cmb_boundary.setFilters(QgsMapLayerProxyModel.Filter.PolygonLayer)

        self.cmb_road = QgsMapLayerComboBox()
        self.cmb_road.setAllowEmptyLayer(True)
        self.cmb_road.setFilters(QgsMapLayerProxyModel.Filter.LineLayer)

        self.cmb_block = QgsMapLayerComboBox()
        self.cmb_block.setAllowEmptyLayer(True)
        self.cmb_block.setFilters(QgsMapLayerProxyModel.Filter.PolygonLayer)

        btn_auto_main = QPushButton("⚡ Projedeki Tüm Katmanları, Yapıları ve Doğal Eşikleri Otomatik Eşleştir")
        if PointingHandCursor is not None:
            btn_auto_main.setCursor(PointingHandCursor)
        btn_auto_main.clicked.connect(self.auto_populate_all_layers)

        f.addRow(QLabel("<b>1) Plan / Onama Sınırı (Poligon):</b>"), self.cmb_boundary)
        f.addRow(QLabel("<b>2) Ulaşım / Yol Ağı (Çizgi):</b>"), self.cmb_road)
        f.addRow(QLabel("<b>3) İmar Adaları / Arazi Kullanımı (Poligon):</b>"), self.cmb_block)
        f.addRow("", btn_auto_main)
        lay.addWidget(g)

        # B. Opsiyonel Tekil Yapılar (Binalar) Katmanı Bölümü
        g_bldg_opt = QGroupBox("B. Opsiyonel Tekil Yapılar / Binalar Katmanı")
        v_bldg = QVBoxLayout(g_bldg_opt)
        v_bldg.setContentsMargins(12, 10, 12, 10)
        v_bldg.setSpacing(8)

        self.chk_use_bldg = QCheckBox("Ayrı bir 'Yapılar / Binalar' katmanım var ve analizlerde (TAKS, kat, yapı nizamı, yapı durumu, nüfus) kullanılmasını istiyorum")
        self.chk_use_bldg.setChecked(False)
        v_bldg.addWidget(self.chk_use_bldg)

        self.bldg_panel = QFrame()
        self.bldg_panel.setStyleSheet("QFrame { background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; }")
        f_bldg = QFormLayout(self.bldg_panel)
        f_bldg.setContentsMargins(12, 10, 12, 10)
        f_bldg.setHorizontalSpacing(14)
        f_bldg.setVerticalSpacing(6)

        self.cmb_bldg = QgsMapLayerComboBox()
        self.cmb_bldg.setAllowEmptyLayer(True)
        self.cmb_bldg.setFilters(QgsMapLayerProxyModel.Filter.PolygonLayer)
        f_bldg.addRow(QLabel("<b>Tekil Yapılar / Binalar Katmanı:</b>"), self.cmb_bldg)

        self.bfld = {}
        self.bfld_info = {}
        for key, label, _, _ in BLDG_FIELD_DEFS:
            c = QgsFieldComboBox()
            c.setAllowEmptyFieldName(True)
            info_lbl = QLabel("<i>Yapı katmanı bekleniyor...</i>")
            c.fieldChanged.connect(lambda fname, k=key: self.update_single_field_preview(self.cmb_bldg.currentLayer(), k, fname, mode="bldg"))
            self.bfld[key] = c
            self.bfld_info[key] = info_lbl
            f_bldg.addRow(label + ":", self._make_field_row_widget(c, info_lbl))

        self.bldg_panel.setVisible(False)
        self.chk_use_bldg.toggled.connect(self.bldg_panel.setVisible)
        v_bldg.addWidget(self.bldg_panel)
        lay.addWidget(g_bldg_opt)

        # C. Nüfus Verisi Giriş Bölümü
        g_pop = QGroupBox("C. Nüfus Verisi Girişi (Otomatik Sütundan veya Manuel Dağıtım)")
        v_pop = QVBoxLayout(g_pop)
        v_pop.setContentsMargins(12, 10, 12, 10)
        v_pop.setSpacing(6)

        self.pop_btn_group = QButtonGroup(self)
        self.rb_pop_col = QRadioButton("1) Otomatik Sütundan Al (Katmandaki nüfus sütununu kullan; boşsa alttaki manuel değeri dağıt)")
        self.rb_pop_manual = QRadioButton("2) Toplam Çalışma Alanı Nüfusunu Elle Gir (Sadece konut ve karma kullanım adalarına ağırlıklı dağıtılır)")
        self.rb_pop_perbldg = QRadioButton("3) Kat / Daire Başına Ortalama Kişi Sayısı İle Hesapla (Yapı sayısı × kat adedi × kat başına kişi)")
        self.rb_pop_col.setChecked(True)

        self.pop_btn_group.addButton(self.rb_pop_col, 1)
        self.pop_btn_group.addButton(self.rb_pop_manual, 2)
        self.pop_btn_group.addButton(self.rb_pop_perbldg, 3)

        v_pop.addWidget(self.rb_pop_col)
        v_pop.addWidget(self.rb_pop_manual)
        v_pop.addWidget(self.rb_pop_perbldg)

        pop_box = QFrame()
        pop_box.setStyleSheet("QFrame { background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 4px; }")
        pop_inputs_lay = QHBoxLayout(pop_box)
        pop_inputs_lay.setContentsMargins(10, 6, 10, 6)
        pop_inputs_lay.setSpacing(12)

        pop_inputs_lay.addWidget(QLabel("<b>Elle Toplam Nüfus:</b>"))
        self.spn_manual_pop = QSpinBox()
        self.spn_manual_pop.setRange(0, 10000000)
        self.spn_manual_pop.setSingleStep(500)
        self.spn_manual_pop.setValue(0)
        self.spn_manual_pop.setSuffix(" kişi")
        self.spn_manual_pop.setMinimumWidth(140)
        self.spn_manual_pop.setToolTip("Çalışma alanının toplam nüfusunu biliyorsanız buraya yazabilirsiniz (Sanayi ve tarım alanlarına 0 nüfus verilir).")
        pop_inputs_lay.addWidget(self.spn_manual_pop)

        pop_inputs_lay.addSpacing(16)
        pop_inputs_lay.addWidget(QLabel("<b>Kat Başına Ortalama Kişi:</b>"))
        self.spn_per_bldg = QDoubleSpinBox()
        self.spn_per_bldg.setRange(0.0, 100.0)
        self.spn_per_bldg.setSingleStep(0.5)
        self.spn_per_bldg.setValue(6.0)
        self.spn_per_bldg.setSuffix(" kişi/kat")
        self.spn_per_bldg.setMinimumWidth(120)
        pop_inputs_lay.addWidget(self.spn_per_bldg)
        pop_inputs_lay.addStretch()

        v_pop.addWidget(pop_box)
        self.rb_pop_col.toggled.connect(self._update_pop_mode_ui)
        self.rb_pop_manual.toggled.connect(self._update_pop_mode_ui)
        self.rb_pop_perbldg.toggled.connect(self._update_pop_mode_ui)
        self._update_pop_mode_ui()
        lay.addWidget(g_pop)

        # D. İmar Adası ve Yol Ağı Sütun Eşleştirmesi (Ferah Yan Yana Kartlar)
        mid_lay = QHBoxLayout()
        mid_lay.setSpacing(10)

        g_blk = QGroupBox("D1. İmar Adası Öznitelikleri (Otomatik Eşleşir)")
        f_blk = QFormLayout(g_blk)
        f_blk.setContentsMargins(12, 10, 12, 10)
        f_blk.setHorizontalSpacing(12)
        f_blk.setVerticalSpacing(6)

        self.fld = {}
        self.fld_info = {}
        for key, label, _, _ in FIELD_DEFS:
            c = QgsFieldComboBox()
            c.setAllowEmptyFieldName(True)
            info_lbl = QLabel("<i>Bekleniyor...</i>")
            c.fieldChanged.connect(lambda fname, k=key: self.update_single_field_preview(self.cmb_block.currentLayer(), k, fname, mode="block"))
            self.fld[key] = c
            self.fld_info[key] = info_lbl
            f_blk.addRow(QLabel(f"<b>{label}:</b>"), self._make_field_row_widget(c, info_lbl))
        mid_lay.addWidget(g_blk, 3)

        g_rd = QGroupBox("D2. Yol Ağı Öznitelikleri (Otomatik Eşleşir)")
        f_rd = QFormLayout(g_rd)
        f_rd.setContentsMargins(12, 10, 12, 10)
        f_rd.setHorizontalSpacing(12)
        f_rd.setVerticalSpacing(6)

        self.rfld = {}
        self.rfld_info = {}
        for key, label, _, _ in ROAD_FIELD_DEFS:
            c = QgsFieldComboBox()
            c.setAllowEmptyFieldName(True)
            info_lbl = QLabel("<i>Bekleniyor...</i>")
            c.fieldChanged.connect(lambda fname, k=key: self.update_single_field_preview(self.cmb_road.currentLayer(), k, fname, mode="road"))
            self.rfld[key] = c
            self.rfld_info[key] = info_lbl
            f_rd.addRow(QLabel(f"<b>{label}:</b>"), self._make_field_row_widget(c, info_lbl))
        mid_lay.addWidget(g_rd, 2)

        lay.addLayout(mid_lay)
        lay.addStretch()

        self.cmb_block.layerChanged.connect(self.on_block_changed)
        self.cmb_bldg.layerChanged.connect(self.on_bldg_changed)
        self.cmb_road.layerChanged.connect(self.on_road_changed)
        QTimer.singleShot(100, self.auto_populate_all_layers)
        return w

    # ------------------------------------------------------------ 2. Sekme: Doğal Eşikler
    def page_extra(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(10, 8, 10, 10)
        lay.setSpacing(10)

        g = QGroupBox("E. Doğal Eşikler, Koruma Alanları ve Donatılar")
        v = QVBoxLayout(g)
        v.setContentsMargins(12, 10, 12, 10)
        v.setSpacing(8)

        bar = QHBoxLayout()
        bar.setSpacing(8)
        btn_auto_nat = QPushButton("⚡ Projedeki Doğal Eşikleri (Dere, Fay, Sit, DEM...) Otomatik Tara")
        if PointingHandCursor is not None:
            btn_auto_nat.setCursor(PointingHandCursor)
        btn_auto_nat.clicked.connect(self.auto_scan_natural_layers)
        b1 = QPushButton("➕ Manuel Satır Ekle")
        if PointingHandCursor is not None:
            b1.setCursor(PointingHandCursor)
        b2 = QPushButton("🗑️ Seçili Satırı Kaldır")
        if PointingHandCursor is not None:
            b2.setCursor(PointingHandCursor)
        b1.clicked.connect(self.add_extra)
        b2.clicked.connect(self.del_extra)
        bar.addWidget(btn_auto_nat)
        bar.addWidget(b1)
        bar.addWidget(b2)
        bar.addStretch()
        v.addLayout(bar)

        self.tbl = QTableWidget(0, 3)
        self.tbl.setAlternatingRowColors(True)
        self.tbl.setMinimumHeight(170)
        self.tbl.verticalHeader().setDefaultSectionSize(32)
        self.tbl.setHorizontalHeaderLabels(["Eşik / Katman Adı", "Analiz Rolü (Otomatik Seçilir)", "Harita Katmanı"])
        self.tbl.horizontalHeader().setSectionResizeMode(HeaderStretch)
        self.tbl.setSelectionBehavior(SelectRows)
        v.addWidget(self.tbl)
        lay.addWidget(g, 1)

        g2 = QGroupBox("F. Sayısal Yükselti Modeli (DEM) / Eğim Katmanı")
        f2 = QFormLayout(g2)
        f2.setContentsMargins(12, 10, 12, 10)
        f2.setHorizontalSpacing(14)
        f2.setVerticalSpacing(8)

        self.cmb_dem = QgsMapLayerComboBox()
        self.cmb_dem.setAllowEmptyLayer(True)
        self.cmb_dem.setFilters(QgsMapLayerProxyModel.Filter.RasterLayer)
        self.chk_slope = QCheckBox("Seçilen raster doğrudan yüzde eğim (%) değerlerini içermektedir")
        self.spn_step = QSpinBox()
        self.spn_step.setRange(5, 200)
        self.spn_step.setValue(30)
        self.spn_step.setSuffix(" m")
        self.spn_step.setMaximumWidth(140)
        f2.addRow(QLabel("<b>DEM veya Eğim Rasterı:</b>"), self.cmb_dem)
        f2.addRow("", self.chk_slope)
        f2.addRow(QLabel("<b>Eğim Çözünürlük Adımı:</b>"), self.spn_step)
        lay.addWidget(g2)
        return w

    def add_extra(self, name_text=None, role_code=None, layer_obj=None):
        row = self.tbl.rowCount()
        self.tbl.insertRow(row)
        role = QComboBox()
        for label, code, _ in analiz.ROLES:
            role.addItem(label, code)
        if role_code:
            idx = role.findData(role_code)
            if idx >= 0:
                role.setCurrentIndex(idx)
        self.tbl.setItem(row, 0, QTableWidgetItem(name_text or f"Katman_{row + 1}"))
        self.tbl.setCellWidget(row, 1, role)
        cmb = QgsMapLayerComboBox()
        cmb.setFilters(QgsMapLayerProxyModel.Filter.VectorLayer)
        if layer_obj:
            cmb.setLayer(layer_obj)
        self.tbl.setCellWidget(row, 2, cmb)

    def del_extra(self):
        for r in sorted({i.row() for i in self.tbl.selectedIndexes()}, reverse=True):
            self.tbl.removeRow(r)

    # ------------------------------------------------------------ Hızlı Otomatik Katman ve Doğal Eşik Tarayıcı
    def auto_populate_all_layers(self):
        proj_layers = list(QgsProject.instance().mapLayers().values())
        if not proj_layers:
            return

        bnd_cand, road_cand, blk_cand, bldg_cand = None, None, None, None
        for lyr in proj_layers:
            nm = alg.norm_tr(lyr.name())
            if any(x in nm for x in ("alt_bolge", "hucre", "imar_adasi_hucre")):
                continue
            if isinstance(lyr, QgsVectorLayer):
                gtype = lyr.geometryType()
                if gtype == QgsWkbTypes.GeometryType.PolygonGeometry:
                    if any(w in nm for w in ("onama", "sinir", "plan_sinir", "calisma_alani", "etap")):
                        bnd_cand = bnd_cand or lyr
                    elif any(w in nm for w in ("bina", "yapi", "building", "tekil")):
                        bldg_cand = bldg_cand or lyr
                    elif any(w in nm for w in ("mevcut", "ada", "parsel", "konut", "nip", "uip")):
                        blk_cand = blk_cand or lyr
                elif gtype == QgsWkbTypes.GeometryType.LineGeometry:
                    if any(w in nm for w in ("yol", "halihazir", "ulası", "ulasi", "sokak", "cadde", "street", "road")):
                        road_cand = road_cand or lyr

        if not blk_cand and bldg_cand:
            blk_cand, bldg_cand = bldg_cand, None

        if bnd_cand:
            self.cmb_boundary.setLayer(bnd_cand)
        if road_cand:
            self.cmb_road.setLayer(road_cand)
        if blk_cand:
            self.cmb_block.setLayer(blk_cand)
        if bldg_cand and bldg_cand != blk_cand:
            self.cmb_bldg.setLayer(bldg_cand)
            self.chk_use_bldg.setChecked(True)

        self.on_block_changed(self.cmb_block.currentLayer())
        self.on_bldg_changed(self.cmb_bldg.currentLayer())
        self.on_road_changed(self.cmb_road.currentLayer())
        self.auto_scan_natural_layers()

    def auto_scan_natural_layers(self):
        proj_layers = list(QgsProject.instance().mapLayers().values())
        used_main = {
            self.cmb_boundary.currentLayer(),
            self.cmb_road.currentLayer(),
            self.cmb_block.currentLayer(),
            self.cmb_bldg.currentLayer() if self.chk_use_bldg.isChecked() else None
        }
        existing_layers = set()
        for r in range(self.tbl.rowCount()):
            w = self.tbl.cellWidget(r, 2)
            if w and w.currentLayer():
                existing_layers.add(w.currentLayer().id())

        for lyr in proj_layers:
            if lyr in used_main or lyr is None:
                continue
            nm = alg.norm_tr(lyr.name())
            if any(x in nm for x in ("alt_bolge", "hucre", "imar_adasi_hucre")):
                continue

            if isinstance(lyr, QgsRasterLayer):
                if any(w in nm for w in ("dem", "srtm", "egim", "slope", "yukseklik", "aster", "alaska", "dsm", "dtm")) or not self.cmb_dem.currentLayer():
                    self.cmb_dem.setLayer(lyr)
                    if "egim" in nm or "slope" in nm:
                        self.chk_slope.setChecked(True)
                continue

            if isinstance(lyr, QgsVectorLayer) and lyr.id() not in existing_layers:
                for role_code, role_title, kws in NATURAL_LAYER_RULES:
                    if any(kw in nm for kw in kws):
                        self.add_extra(name_text=f"{role_title} ({lyr.name()})", role_code=role_code, layer_obj=lyr)
                        existing_layers.add(lyr.id())
                        break

    # ------------------------------------------------------------ Sütun Önizleme Motoru
    def sample_column_values(self, layer, fname, max_rows=80):
        if not layer or not fname:
            return []
        cache_key = (layer.id(), fname, max_rows)
        if cache_key in self._sample_cache:
            return self._sample_cache[cache_key]
        vals = []
        req = QgsFeatureRequest().setFlags(QgsFeatureRequest.Flag.NoGeometry).setSubsetOfAttributes([fname], layer.fields()).setLimit(max_rows)
        for f in layer.getFeatures(req):
            v = analiz.val(f, fname)
            if v is not None:
                vals.append(v)
        self._sample_cache[cache_key] = vals
        return vals

    def smart_match_field(self, layer, kws, want_numeric, exclude_cols=None):
        if not layer:
            return ""
        excl = exclude_cols or set()
        best_col = ""
        best_score = -1
        for fl in layer.fields():
            fname = fl.name()
            if fname in excl:
                continue
            nm = alg.norm_tr(fname)
            if nm in ("id", "fid", "gid", "objectid", "shape_leng", "shape_area"):
                continue
            score = 0
            for kw in kws:
                if nm == kw:
                    score += 50
                elif kw in nm:
                    score += 25
            samples = self.sample_column_values(layer, fname, 50)
            if not samples:
                continue
            if want_numeric:
                num_ok = sum(1 for x in samples if analiz.to_float(x) is not None)
                if num_ok > len(samples) * 0.6:
                    score += 10
                else:
                    score -= 15
            else:
                joined = " ".join(alg.norm_tr(x) for x in samples[:25])
                if any(w in joined for w in ("konut", "ticaret", "tarim", "sanayi", "bitisik", "ayrik", "asfalt", "parke", "sokak", "bulvar", "iyi", "orta", "kotu")):
                    score += 12
            if score > best_score and score >= 15:
                best_score = score
                best_col = fname
        return best_col

    def update_single_field_preview(self, layer, key, fname, mode="block"):
        if mode == "road":
            lbl = self.rfld_info[key]
        elif mode == "bldg":
            lbl = self.bfld_info[key]
        else:
            lbl = self.fld_info[key]

        if not layer:
            lbl.setText("<i>Katman seçilmedi</i>")
            return
        if not fname:
            lbl.setText("<span style='color:#64748b;'>Kullanılmıyor</span>")
            return
        samples = self.sample_column_values(layer, fname, 80)
        if not samples:
            lbl.setText(f"<span style='color:#d97706;'>Boş sütun ({fname})</span>")
            return
        str_counts = Counter(str(x).strip() for x in samples).most_common(3)
        preview_str = ", ".join(f"{val} ({cnt})" for val, cnt in str_counts)
        if len(preview_str) > 54:
            preview_str = preview_str[:51] + "..."
        lbl.setText(f"<span style='color:#15803d;'>✔ <b>{fname}:</b> {preview_str}</span>")

    def on_block_changed(self, layer):
        self._sample_cache.clear()
        used = set()
        for key, _, kws, want_num in FIELD_DEFS:
            c = self.fld[key]
            c.blockSignals(True)
            c.setLayer(layer)
            matched = self.smart_match_field(layer, kws, want_num, exclude_cols=used)
            if matched:
                used.add(matched)
            c.setField(matched)
            c.blockSignals(False)
            self.update_single_field_preview(layer, key, matched, mode="block")

    def on_bldg_changed(self, layer):
        self._sample_cache.clear()
        used = set()
        for key, _, kws, want_num in BLDG_FIELD_DEFS:
            c = self.bfld[key]
            c.blockSignals(True)
            c.setLayer(layer)
            matched = self.smart_match_field(layer, kws, want_num, exclude_cols=used)
            if matched:
                used.add(matched)
            c.setField(matched)
            c.blockSignals(False)
            self.update_single_field_preview(layer, key, matched, mode="bldg")

    def on_road_changed(self, layer):
        self._sample_cache.clear()
        used = set()
        for key, _, kws, want_num in ROAD_FIELD_DEFS:
            c = self.rfld[key]
            c.blockSignals(True)
            c.setLayer(layer)
            matched = self.smart_match_field(layer, kws, want_num, exclude_cols=used)
            if matched:
                used.add(matched)
            c.setField(matched)
            c.blockSignals(False)
            self.update_single_field_preview(layer, key, matched, mode="road")

    def _update_pop_mode_ui(self):
        mode_id = self.pop_btn_group.checkedId()
        self.spn_manual_pop.setEnabled(mode_id in (1, 2))
        self.spn_per_bldg.setEnabled(mode_id == 3)
        if mode_id == 2:
            self.spn_manual_pop.setStyleSheet("border: 1.5px solid #0284c7; background-color: #f0f9ff;")
            self.spn_per_bldg.setStyleSheet("")
        elif mode_id == 3:
            self.spn_per_bldg.setStyleSheet("border: 1.5px solid #0284c7; background-color: #f0f9ff;")
            self.spn_manual_pop.setStyleSheet("")
        else:
            self.spn_manual_pop.setStyleSheet("")
            self.spn_per_bldg.setStyleSheet("")

    # ------------------------------------------------------------ 3. Sekme: Ağırlıklar & Ayarlar (2 Sütunlu Modern Grid Kartlar)
    def page_settings(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(10, 8, 10, 10)
        lay.setSpacing(10)

        g = QGroupBox("G. Bölgeleme Parametreleri ve Ağırlık Katsayıları")
        grid = QGridLayout(g)
        grid.setContentsMargins(12, 12, 12, 12)
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(10)

        def make_param_card(title_text, widget, desc_text):
            card = QFrame()
            card.setStyleSheet(
                "QFrame { background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; }"
            )
            cl = QVBoxLayout(card)
            cl.setContentsMargins(10, 8, 10, 8)
            cl.setSpacing(4)
            top_row = QHBoxLayout()
            lbl_t = QLabel(f"<b>{title_text}</b>")
            lbl_t.setStyleSheet("border: none; background: transparent; color: #0f172a;")
            widget.setMinimumWidth(95)
            top_row.addWidget(lbl_t, 1)
            top_row.addWidget(widget)
            cl.addLayout(top_row)
            lbl_d = QLabel(desc_text)
            lbl_d.setWordWrap(True)
            lbl_d.setStyleSheet("border: none; background: transparent; color: #475569; font-size: 11px;")
            cl.addWidget(lbl_d)
            return card

        def dsp(v, lo=0.0, hi=5.0, step=0.1):
            d = QDoubleSpinBox()
            d.setRange(lo, hi)
            d.setSingleStep(step)
            d.setValue(v)
            return d

        self.spn_k = QSpinBox()
        self.spn_k.setRange(2, 60)
        self.spn_k.setValue(28)

        self.w_lu = dsp(1.2)
        self.w_yapi = dsp(1.0)
        self.w_dogal = dsp(1.0)
        self.w_geo = dsp(1.0)
        self.cap = dsp(4.0, 1.5, 20.0, 0.5)

        self.grid = QSpinBox()
        self.grid.setRange(50, 2000)
        self.grid.setValue(200)
        self.grid.setSuffix(" m")

        grid.addWidget(make_param_card("1) Hedef Alt Bölge Sayısı", self.spn_k, "Çalışma alanının bölüneceği toplam alt bölge adedi (Standart: 28 -> A1..A28)."), 0, 0)
        grid.addWidget(make_param_card("2) Arazi Kullanımı Ağırlığı", self.w_lu, "Artırıldığında konut, ticaret, sanayi, tarım ve donatı alanlarını birbirinden keskin ayırır."), 0, 1)
        grid.addWidget(make_param_card("3) Yapı / Kat / Nüfus / Yol Ağırlığı", self.w_yapi, "Artırıldığında TAKS, kat adedi, yapı nizamı, kötü yapı oranı ve nüfus yoğunluğu farklı adaları ayırır."), 1, 0)
        grid.addWidget(make_param_card("4) Doğal Eşik ve Koruma Ağırlığı", self.w_dogal, "Artırıldığında dere yatağı, eğimli topoğrafya, fay ve sit/risk alanlarını bağımsız bölge yapar."), 1, 1)
        grid.addWidget(make_param_card("5) Mekânsal Kompaktlık Ağırlığı", self.w_geo, "Artırıldığında ince uzun şeritler yerine derli toplu/kompakt mahalle geometrileri oluşturur."), 2, 0)
        grid.addWidget(make_param_card("6) Azami Alan Büyüklük Tavanı", self.cap, "Bir alt bölgenin ortalama bölge büyüklüğünün en fazla kaç katı olabileceğini belirler."), 2, 1)
        grid.addWidget(make_param_card("7) Yedek Izgara Boyutu", self.grid, "Yol ağı katmanı verilmediğinde kullanılacak varsayılan ızgara hücre genişliği."), 3, 0, 1, 2)

        lay.addWidget(g)

        g_opts = QGroupBox("H. Geometri, Hızlı Özet Katmanı ve Eşleştirme Seçenekleri")
        v_opts = QVBoxLayout(g_opts)
        v_opts.setContentsMargins(12, 10, 12, 10)
        v_opts.setSpacing(6)

        self.chk_filter_medians = QCheckBox("Yol içi refüj ve kavşak adacıklarını süz (Yollar yalnızca sınır oluşturur, tek başına alan olamaz)")
        self.chk_filter_medians.setChecked(True)
        self.chk_excel = QCheckBox("Alt bölgeleri A1..A28 gerekçe profilleriyle eşleştir")
        self.chk_excel.setChecked(True)
        self.chk_quick_layer = QCheckBox("Haritaya ayrıca sadeleştirilmiş 'Alt_Bolgeler_Hizli_Ozet' katmanı ekle (Sadece hızlı okuma sütunları)")
        self.chk_quick_layer.setChecked(True)
        self.chk_cells = QCheckBox("Ara işlem katmanı olan imar adası hücrelerini haritaya ekle")

        v_opts.addWidget(self.chk_filter_medians)
        v_opts.addWidget(self.chk_excel)
        v_opts.addWidget(self.chk_quick_layer)
        v_opts.addWidget(self.chk_cells)

        lay.addWidget(g_opts)
        lay.addStretch()
        return w

    # ------------------------------------------------------------ 4. Sekme: Sınır Ayrım Gerekçeleri & Rapor
    def page_results(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(10, 8, 10, 10)
        gl = QGroupBox("I. Alt Bölgeleme Özeti, İç Bütünlük ve Komşu Bölgelerden Ayrım Gerekçeleri")
        v = QVBoxLayout(gl)
        v.setContentsMargins(10, 10, 10, 10)
        v.setSpacing(8)

        # Üst Görünüm Modu Seçici (Hızlı Özet vs. Detaylı Teknik Doğrulama)
        ctrl_frame = QFrame()
        ctrl_frame.setStyleSheet(
            "QFrame { background-color: #f0f9ff; border: 1px solid #bae6fd; border-radius: 6px; padding: 6px; }"
        )
        ctrl_lay = QVBoxLayout(ctrl_frame)
        ctrl_lay.setContentsMargins(8, 6, 8, 6)
        ctrl_lay.setSpacing(6)

        row_modes = QHBoxLayout()
        row_modes.setSpacing(10)
        self.lbl_view_mode = QLabel("<b>Görünüm Modu:</b>")
        self.lbl_view_mode.setStyleSheet("color: #0369a1; border: none; background: transparent;")
        row_modes.addWidget(self.lbl_view_mode)

        self.view_btn_group = QButtonGroup(self)
        self.rb_view_quick = QRadioButton("⚡ Hızlı ve Sade Özet (Hızlı Okuma)")
        self.rb_view_quick.setToolTip("Teknik kodları ([yapi:kotu_yapi], [sit2], [ΔZ]) gizler; sadece % Kullanım, Fay, Dere, Eğim, Donatı, TAKS, Kat ve 1 cümlelik sade ayrım nedenini gösterir.")
        self.rb_view_both = QRadioButton("📋 İkisi Bir Arada (Özet + Detay)")
        self.rb_view_both.setToolTip("Üst satırda hızlı okuma özetini, alt satırda ise Z-skoru ve tüm teknik doğrulama verilerini birlikte gösterir.")
        self.rb_view_detailed = QRadioButton("🔬 Sadece Detaylı Teknik (ΔZ & Kodlar)")
        self.rb_view_detailed.setToolTip("Jüri ve akademik kontrol için tüm parametre kodlarını ([yapi:kotu_yapi], [sit2], [sit3]) ve ΔZ matris farklarını gösterir.")
        self.rb_view_both.setChecked(True)

        for idx_rb, rb in enumerate((self.rb_view_quick, self.rb_view_both, self.rb_view_detailed), 1):
            rb.setStyleSheet("font-weight: 600; color: #0f172a; border: none; background: transparent;")
            self.view_btn_group.addButton(rb, idx_rb)
            row_modes.addWidget(rb)
            rb.toggled.connect(self.refresh_report_view)
        row_modes.addStretch()
        ctrl_lay.addLayout(row_modes)

        row_filter = QHBoxLayout()
        row_filter.setSpacing(8)
        self.txt_filter = QLineEdit()
        self.txt_filter.setPlaceholderText("🔍 Bölge kodu veya anahtar kelime filtrele (ör: M26, Konut, Fay, Donatı, Sit)...")
        self.txt_filter.setStyleSheet(
            "QLineEdit { background-color: #ffffff; border: 1px solid #94a3b8; border-radius: 5px; padding: 4px 8px; }"
        )
        self.txt_filter.textChanged.connect(self.refresh_report_view)
        row_filter.addWidget(self.txt_filter, 1)
        ctrl_lay.addLayout(row_filter)
        v.addWidget(ctrl_frame)

        self.txt = QTextEdit()
        self.txt.setReadOnly(True)
        self.txt.setPlaceholderText(
            "▶ 'ÇALIŞTIR' düğmesine bastığınızda her alt bölgenin:\n"
            "• ⚡ HIZLI VE SADE ÖZETİ (% Konut/Ticaret/Tarım, Faya Uzaklık, Dereye Uzaklık, Eğim, Donatı Sayısı, TAKS, Kat ve 1 cümlelik sade ayrım nedeni),\n"
            "• 🔬 DETAYLI TEKNİK DOĞRULAMA VERİSİ (Z-Skoru matrisi [ΔZ], yapi:kotu_yapi, sit2, sit3 ve iç bütünlük parametreleri)\n"
            "seçtiğiniz görünüm moduna göre burada net ve düzenli biçimde listelenir."
        )
        v.addWidget(self.txt)
        lay.addWidget(gl, 1)
        return w

    # ------------------------------------------------------------ 5. Sekme: MPYY & Metodoloji El Kitabı
    def page_about(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(10, 8, 10, 10)
        lay.setSpacing(8)

        # Üst Rehber Çubuğu
        top_box = QHBoxLayout()
        lbl_info = QLabel("<b>Mekânsal Analiz Metodolojisi, MAUP Çözümü ve Kapsamlı Kullanım El Kitabı:</b>")
        lbl_info.setStyleSheet("color: #0f172a; font-size: 12px;")
        btn_browser = QPushButton("🌐 Bu El Kitabını Tam Sayfa Tarayıcıda Aç (HTML)")
        btn_browser.setObjectName("helpBtn")
        if PointingHandCursor is not None:
            btn_browser.setCursor(PointingHandCursor)
        btn_browser.clicked.connect(self.open_html_guide)
        top_box.addWidget(lbl_info, 1)
        top_box.addWidget(btn_browser)
        lay.addLayout(top_box)

        g = QGroupBox("J. Kapsamlı Metodoloji, MAUP Çözümü ve Adım Adım Kullanım Kılavuzu")
        v = QVBoxLayout(g)
        v.setContentsMargins(8, 8, 8, 8)
        about_txt = QTextEdit()
        about_txt.setReadOnly(True)
        guide_path = os.path.join(self.plugin_dir, "KULLANIM_KILAVUZU.html")
        if os.path.exists(guide_path):
            try:
                with open(guide_path, "r", encoding="utf-8") as f:
                    about_txt.setHtml(f.read())
            except (OSError, UnicodeDecodeError):
                about_txt.setPlainText("Kılavuz yüklenirken hata oluştu.")
        v.addWidget(about_txt)
        lay.addWidget(g, 1)
        return w

    def open_html_guide(self):
        guide_path = os.path.join(self.plugin_dir, "KULLANIM_KILAVUZU.html")
        if os.path.exists(guide_path):
            import webbrowser
            webbrowser.open(f"file:///{os.path.abspath(guide_path).replace(os.sep, '/')}")
        else:
            QMessageBox.information(self, "Kılavuz", "Kullanım kılavuzu dosyası bulunamadı.")

    # ------------------------------------------------------------ çalıştırma ve görünüm yenileme
    def log(self, m):
        self._pipeline_logs.append(m)
        self.txt.append(m)
        QApplication.processEvents()

    def refresh_report_view(self):
        """Kullanıcı Hızlı Özet / İkisi Bir Arada / Detaylı Teknik modunu değiştirdiğinde veya filtre yazdığında raporu anında günceller."""
        if not getattr(self, "last_zones", None):
            return
        view_id = self.view_btn_group.checkedId() if hasattr(self, "view_btn_group") else 2
        q_filter = (self.txt_filter.text().strip().lower() if hasattr(self, "txt_filter") else "")

        lines = []
        for msg in getattr(self, "_pipeline_logs", []):
            lines.append(msg)

        if view_id == 1:
            lines.append("=" * 84)
            lines.append("⚡ HIZLI VE SADE ÖZET GÖRÜNÜMÜ (Hızlı Okuma: % Kullanım | Fay | Eğim | Donatı | TAKS | Kat)")
            lines.append("=" * 84)
        elif view_id == 2:
            lines.append("=" * 84)
            lines.append("📋 İKİSİ BİR ARADA GÖRÜNÜM (Üstte Hızlı Okuma Özeti + Altta Detaylı Teknik & Z-Skoru Doğrulama)")
            lines.append("=" * 84)
        else:
            lines.append("=" * 84)
            lines.append("🔬 DETAYLI TEKNİK & Z-SKORU DOĞRULAMA GÖRÜNÜMÜ (Tüm Parametre Kodları & ΔZ Matrisi)")
            lines.append("=" * 84)

        shown = 0
        for z in self.last_zones:
            ha = z["area"] / 10000.0
            kisa_ozet = z.get("kisa_ozet") or analiz.describe_quick_summary(z)
            kisa_ayrim = z.get("kisa_ayrim_nedeni") or ""
            excel_ger = z.get("excel_gerekce") or ""
            searchable = f"{z['kod']} {z['karakter']} {kisa_ozet} {kisa_ayrim} {z['olculen']} {z['gerekce']}".lower()
            if q_filter and q_filter not in searchable:
                continue
            shown += 1

            if view_id == 1:
                # SADECE HIZLI VE SADE ÖZET (Tek bakışta okuma, sıfır kod karmaşası)
                block_str = (
                    f"■ {z['kod']} — {z['karakter']} ({ha:.1f} ha)\n"
                    f"   📌 Hızlı Metrikler : {kisa_ozet}\n"
                    f"   🔹 Neden Ayrıldı   : {excel_ger} {kisa_ayrim}"
                )
                if z.get("mudahale_karari"):
                    block_str += f"\n   🎯 Müdahale Kararı : {z['mudahale_karari']}"
                lines.append(block_str + "\n" + "-" * 84)
            elif view_id == 2:
                # İKİSİ BİR ARADA (Üstte Hızlı Özet + Altta Detaylı Teknik Doğrulama)
                block_str = (
                    f"■ {z['kod']} — {z['karakter']} ({ha:.1f} ha | {z['olculen']})\n"
                    f"   ⚡ [HIZLI ÖZET]     : {kisa_ozet}\n"
                    f"   🔹 [SADE AYRIM]     : {excel_ger} {kisa_ayrim}\n"
                    f"   • Neden Birleşti & Ayrıldı (Detaylı Teknik & ΔZ): {z['gerekce']}"
                )
                if z.get("mudahale_karari"):
                    block_str += f"\n   🎯 [MÜDAHALE & PLAN]: {z['mudahale_karari']} ({z.get('plan_karsiligi') or ''})"
                lines.append(block_str + "\n" + "-" * 84)
            else:
                # SADECE DETAYLI TEKNİK DOĞRULAMA
                lines.append(
                    f"■ {z['kod']} — {z['karakter']} ({ha:.1f} ha | {z['olculen']})\n"
                    f"   • Neden Birleşti & Ayrıldı: {z['gerekce']}\n" + "-" * 84
                )

        lines.append(f"✔ Analiz tamamlandı ({len(self.last_zones)} alt bölge haritaya eklendi, {shown} bölge görüntüleniyor).")
        self.txt.setPlainText("\n".join(lines))

    def run(self, interactive=True):
        bnd = self.cmb_boundary.currentLayer()
        road = self.cmb_road.currentLayer()
        blk = self.cmb_block.currentLayer()
        bldg = self.cmb_bldg.currentLayer() if self.chk_use_bldg.isChecked() else None

        if not bnd and not blk and not bldg and not road:
            msg = "Lütfen en azından Plan Sınırı, Yol Ağı, İmar Adası veya Yapı katmanlarından birini seçiniz."
            if interactive:
                QMessageBox.warning(self, "Eksik Katman", msg)
            else:
                self.log("✖ UYARI: " + msg)
            return False

        extras = []
        for r in range(self.tbl.rowCount()):
            lyr = self.tbl.cellWidget(r, 2).currentLayer()
            if lyr is None:
                continue
            combo = self.tbl.cellWidget(r, 1)
            extras.append({
                "name": self.tbl.item(r, 0).text().strip() or f"Katman_{r + 1}",
                "role": combo.currentData(),
                "layer": lyr
            })

        pop_mode_id = self.pop_btn_group.checkedId()
        pop_mode = "auto" if pop_mode_id == 1 else ("manual_total" if pop_mode_id == 2 else "per_building")
        pop_cfg = {
            "mode": pop_mode,
            "manual_total": self.spn_manual_pop.value(),
            "per_bldg": self.spn_per_bldg.value()
        }

        base_lyr = bnd or blk or bldg or road
        P = {
            "mode": self.cmb_mode.currentData() if hasattr(self, "cmb_mode") else "advanced",
            "work_crs": base_lyr.crs(),
            "boundary_layer": bnd,
            "road_layer": road,
            "block_layer": blk,
            "bldg_layer": bldg,
            "fields": {k: (c.currentField() or None) for k, c in self.fld.items()},
            "bfields": {k: (c.currentField() or None) for k, c in self.bfld.items()},
            "rfields": {k: (c.currentField() or None) for k, c in self.rfld.items()},
            "pop_cfg": pop_cfg,
            "extras": extras,
            "dem": self.cmb_dem.currentLayer(),
            "dem_is_slope": self.chk_slope.isChecked(),
            "dem_step": float(self.spn_step.value()),
            "K": self.spn_k.value(),
            "w_lu": self.w_lu.value(),
            "w_yapi": self.w_yapi.value(),
            "w_dogal": self.w_dogal.value(),
            "w_geo": self.w_geo.value(),
            "cap_mult": self.cap.value(),
            "grid_size": float(self.grid.value()),
            "filter_medians": self.chk_filter_medians.isChecked(),
            "use_excel": self.chk_excel.isChecked(),
        }
        self.last_P = P
        self._pipeline_logs = []
        self.txt.clear()
        self.tabs.setCurrentIndex(3)
        self.btn_run.setEnabled(False)
        self.btn_top_run.setEnabled(False)
        if WaitCursor is not None:
            QApplication.setOverrideCursor(WaitCursor)
        try:
            res = analiz.run_pipeline(P, self.log, self.progress.setValue)
            lyr, self.records = analiz.make_zone_layer(res, quick_only=False)
            lyr_quick, self.quick_records = analiz.make_zone_layer(res, quick_only=True)
            if self.chk_cells.isChecked():
                QgsProject.instance().addMapLayer(analiz.make_cell_layer(res))
            if hasattr(self, "chk_quick_layer") and self.chk_quick_layer.isChecked():
                QgsProject.instance().addMapLayer(lyr_quick)
            QgsProject.instance().addMapLayer(lyr)
            if self.iface and hasattr(self.iface, "mapCanvas") and self.iface.mapCanvas():
                self.iface.mapCanvas().refresh()

            active_col_names = ", ".join(self.records[0].keys()) if self.records else ""
            self._pipeline_logs.append(f"✔ Boş (NULL) sütunlar temizlendi. Aktif dolu sütunlar:\n   [{active_col_names}]")

            self.last_zones = res["zones"]
            self.refresh_report_view()
            self.btn_quick_csv.setEnabled(True)
            self.btn_csv.setEnabled(True)
            self.btn_matrix.setEnabled(True)
            self.progress.setValue(100)
            return True
        except Exception as e:
            self.log("✖ HATA: " + str(e) + "\n" + traceback.format_exc())
            if interactive:
                QMessageBox.critical(self, "Analiz Hatası", str(e))
            raise
        finally:
            if WaitCursor is not None:
                QApplication.restoreOverrideCursor()
            self.btn_run.setEnabled(True)
            self.btn_top_run.setEnabled(True)

    def export_quick_csv(self, target_path=None):
        """Sadece hızlı okuma metriklerini ve sade ayrım gerekçesini içeren özet CSV tablosunu dışa aktarır."""
        recs = getattr(self, "quick_records", None) or self.records
        if not recs:
            return None
        if target_path:
            path = target_path
        else:
            default_fname = "Alt_Bolgeler_Hizli_Ozet_Tablo.csv"
            path, _ = QFileDialog.getSaveFileName(self, "Hızlı Özet Tablosunu Kaydet (Sade CSV)", default_fname, "CSV (*.csv)")
            if not path:
                return None
        keys = list(recs[0].keys())
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=keys, delimiter=";")
            w.writeheader()
            w.writerows(recs)
        if not target_path:
            QMessageBox.information(self, "Kaydedildi", f"Hızlı okuma için sadeleştirilmiş özet tablo kaydedildi:\n{path}")
        return path

    def export_csv(self, target_path=None):
        if not self.records:
            return None
        if target_path:
            path = target_path
        else:
            is_adv = (self.cmb_mode.currentData() == "advanced") if hasattr(self, "cmb_mode") else True
            default_fname = "Alt_Bolgeler_M1_M28_Mudahale_Atlasi.csv" if is_adv else "Alt_Bolgeler_A1_A28_Tablo.csv"
            path, _ = QFileDialog.getSaveFileName(self, "Alt Bölge Tablosunu Kaydet", default_fname, "CSV (*.csv)")
            if not path:
                return None
        keys = list(self.records[0].keys())
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=keys, delimiter=";")
            w.writeheader()
            w.writerows(self.records)
        if not target_path:
            QMessageBox.information(self, "Kaydedildi", f"Boş sütunlardan arındırılmış açık isimli tablo kaydedildi: {path}")
        return path

    def export_analysis_matrix(self, target_path=None):
        if not hasattr(self, "last_P") or not self.last_P:
            return None
        if target_path:
            path = target_path
        else:
            path, _ = QFileDialog.getSaveFileName(self, "Analiz İzleme Matrisini Kaydet", "Analiz_Izleme_Matrisi.csv", "CSV (*.csv)")
            if not path:
                return None
        analiz.export_analysis_tracking_matrix(self.last_P, getattr(self, "last_zones", None), path)
        if not target_path:
            QMessageBox.information(self, "Kaydedildi", f"Öksüz analiz yok ilkesine dayalı Analiz İzleme Matrisi kaydedildi:\n{path}")
        return path

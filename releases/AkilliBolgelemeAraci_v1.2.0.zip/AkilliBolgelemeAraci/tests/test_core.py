# -*- coding: utf-8 -*-
"""Akıllı Bölgeleme Aracı - Saf Python Çekirdek Birim Testleri.

QGIS ortamı gerektirmeden saf Python ile çalıştırılabilir:
  python tests/test_core.py
  veya
  python -m unittest discover -s tests
"""

import math
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PLUGIN_ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(PLUGIN_ROOT))

from AkilliBolgelemeAraci import algoritma as alg


class AlgoritmaCoreTests(unittest.TestCase):
    def test_norm_tr(self):
        self.assertEqual(alg.norm_tr("İZMİR"), "izmir")
        self.assertEqual(alg.norm_tr("Çarşı ve Park"), "carsi ve park")
        self.assertEqual(alg.norm_tr("ŞEHİR PLANLAMA"), "sehir planlama")
        self.assertEqual(alg.norm_tr("Ağaçlık Alan"), "agaclik alan")
        self.assertEqual(alg.norm_tr("Ilık Su"), "ilik su")

    def test_classify_landuse_simple(self):
        res = alg.classify_landuse("Konut Alanı")
        self.assertIn("konut", res)
        self.assertAlmostEqual(res["konut"], 1.0)

        res_san = alg.classify_landuse("Organize Sanayi Bölgesi Fabrika")
        self.assertEqual(res_san, {"sanayi": 1.0})

        res_tar = alg.classify_landuse("Zeytinlik ve Tarla")
        self.assertEqual(res_tar, {"tarim": 1.0})

        res_tic = alg.classify_landuse("Ticaret ve Dükkan Aksı")
        self.assertIn("ticaret", res_tic)

        res_don = alg.classify_landuse("İlkokul ve Sağlık Ocağı")
        self.assertIn("donati", res_don)

    def test_classify_landuse_priorities(self):
        # Güçlü koruma ve sanayi önceliği (sit, sanayi)
        res_sit = alg.classify_landuse("Arkeolojik Sit ve Konut")
        self.assertEqual(res_sit, {"sit": 1.0})

        res_san = alg.classify_landuse("Küçük Sanayi Sitesi ve Ticaret")
        self.assertEqual(res_san, {"sanayi": 1.0})

    def test_classify_landuse_empty_or_unknown(self):
        self.assertEqual(alg.classify_landuse(""), {})
        self.assertEqual(alg.classify_landuse(None), {})
        self.assertEqual(alg.classify_landuse("Bilinmeyen Nitelik XYZ"), {"diger": 1.0})

    def test_is_road_island_text(self):
        self.assertTrue(alg.is_road_island_text("Orta Refüj"))
        self.assertTrue(alg.is_road_island_text("Trafik Adası"))
        self.assertTrue(alg.is_road_island_text("Dönel Kavşak Göbeği"))
        self.assertFalse(alg.is_road_island_text("Konut Parseli"))
        self.assertFalse(alg.is_road_island_text(None))

    def test_median(self):
        self.assertEqual(alg.median([]), 0.0)
        self.assertEqual(alg.median([5.0]), 5.0)
        self.assertEqual(alg.median([1.0, 3.0, 2.0]), 2.0)
        self.assertEqual(alg.median([1.0, 2.0, 3.0, 4.0]), 2.5)

    def test_zscore_columns(self):
        cols = {
            "c1": [10.0, 20.0, 30.0],
            "zero_var": [5.0, 5.0, 5.0],
            "empty": [],
        }
        z, dropped = alg.zscore_columns(cols)
        self.assertIn("c1", z)
        self.assertEqual(set(dropped), {"zero_var", "empty"})
        # c1 ortalaması 20.0, std = sqrt((100+0+100)/3) = sqrt(200/3) = 8.1649658
        self.assertAlmostEqual(z["c1"][1], 0.0)
        self.assertAlmostEqual(z["c1"][0], -z["c1"][2])

    def test_percentile_rank(self):
        vals = [10.0, 20.0, 30.0, 40.0, 50.0]
        ranks = alg.percentile_rank(vals)
        self.assertEqual(ranks[0], 0.0)
        self.assertEqual(ranks[-1], 1.0)
        self.assertEqual(ranks[2], 0.5)

        # Eşitlik durumu (ties)
        ranks_ties = alg.percentile_rank([10.0, 20.0, 20.0, 30.0])
        self.assertEqual(ranks_ties[1], ranks_ties[2])

    def test_hungarian_algorithm(self):
        cost_matrix = [
            [4.0, 1.0, 3.0],
            [2.0, 0.5, 5.0],
            [3.0, 2.0, 2.0],
        ]
        assign = alg.hungarian(cost_matrix)
        self.assertEqual(len(assign), 3)
        self.assertEqual(len(set(assign)), 3)
        # Optimal atama toplam maliyeti en küçük olan olmalı
        total_cost = sum(cost_matrix[i][assign[i]] for i in range(3))
        # Olası atamalar: i0->j1 (1.0), i1->j0 (2.0), i2->j2 (2.0) = 5.0
        self.assertAlmostEqual(total_cost, 5.0)

    def test_connect_components(self):
        # 4 nokta: (0,0) ve (1,0) bir bileşen; (10,0) ve (11,0) ayrı bileşen
        pts = [(0.0, 0.0), (1.0, 0.0), (10.0, 0.0), (11.0, 0.0)]
        adj = {0: {1}, 1: {0}, 2: {3}, 3: {2}}
        comp_count = alg.connect_components(adj, pts)
        self.assertEqual(comp_count, 1)
        # 1 ile 2 arasında en yakın bağlantı kurulmuş olmalı
        self.assertTrue(1 in adj[2] and 2 in adj[1])

    def test_ward_merge(self):
        # 4 ardışık hücre: 0 - 1 - 2 - 3
        # 0 ve 1 benzer vektörlere sahip (örn. [0.0]), 2 ve 3 benzer ([5.0])
        vecs = [[0.0], [0.1], [5.0], [5.1]]
        node_w = [1.0, 1.0, 1.0, 1.0]
        areas = [100.0, 100.0, 100.0, 100.0]
        adj = {
            0: {1},
            1: {0, 2},
            2: {1, 3},
            3: {2},
        }
        labels = alg.ward_merge(vecs, node_w, areas, adj, target_k=2)
        self.assertEqual(len(labels), 4)
        # 0 ve 1 aynı grupta olmalı, 2 ve 3 aynı grupta olmalı
        self.assertEqual(labels[0], labels[1])
        self.assertEqual(labels[2], labels[3])
        self.assertNotEqual(labels[0], labels[2])

    def test_excel_rows_matching(self):
        zone_feats = [
            {"sanayi": 0.9, "dens": 0.2, "dir": (-0.7, 0.7)},  # NW sanayi
            {"sit": 0.8, "merkez": 0.9, "ticaret": 0.3},       # Sit
        ]
        matches = alg.match_zones_to_rows(zone_feats)
        self.assertEqual(len(matches), 2)
        # İlk bölge A28 (Sanayi) ile eşleşmeli
        assigned_row_idx = matches[0][0]
        self.assertEqual(alg.EXCEL_ROWS[assigned_row_idx][0], "A28")


    def test_zscore_clipping(self):
        # Aşırı uç değer içeren sütun: clip=[-3, 3] aralığına kırpılmalı
        cols = {"extreme": [-1000.0, 0.0, 0.0, 0.0, 0.0, 1000.0]}
        z, dropped = alg.zscore_columns(cols, clip=2.5)
        self.assertIn("extreme", z)
        for val in z["extreme"]:
            self.assertTrue(-2.5 <= val <= 2.5)

    def test_classify_all_lu_categories(self):
        tests = [
            ("Konut Rezidans ve Yaşam Alanı", "konut"),
            ("Banka Ofis Mağaza Dükkan", "ticaret"),
            ("Ağır Sanayi Fabrika İmalat", "sanayi"),
            ("Mera Tarla Zeytinlik Ziraat", "tarim"),
            ("Devlet Hastanesi Sağlık Poliklinik", "donati"),
            ("Arkeolojik Sit Alanı Tescil", "sit"),
        ]
        for text, expected in tests:
            res = alg.classify_landuse(text)
            self.assertIn(expected, res, f"Metin '{text}' içinde '{expected}' bulunamadı: {res}")

    def test_classify_karma_usage(self):
        # Ticaret ve konut bir arada
        res = alg.classify_landuse("Zemin Dükkan Üstü Apartman Konut")
        self.assertIn("ticaret", res)
        self.assertIn("konut", res)
        self.assertAlmostEqual(res["ticaret"], 0.5)
        self.assertAlmostEqual(res["konut"], 0.5)

    def test_hungarian_errors(self):
        # Satır > Sütun hatası fırlatmalı
        with self.assertRaises(ValueError):
            alg.hungarian([[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]])

    def test_ward_merge_target_k_greater_than_nodes(self):
        # Eğer K >= n ise doğrudan mevcut etiketler dönmeli
        vecs = [[1.0], [2.0]]
        node_w = [1.0, 1.0]
        areas = [10.0, 20.0]
        adj = {0: {1}, 1: {0}}
        labels = alg.ward_merge(vecs, node_w, areas, adj, target_k=5)
        self.assertEqual(len(set(labels)), 2)

    def test_match_cost_direction(self):
        zone_west = {"sanayi": 0.5, "dir": (-1.0, 0.0)}
        zone_east = {"sanayi": 0.5, "dir": (1.0, 0.0)}
        row_west = ("A1", "Test", "Gerekçe", {"sanayi": 0.5}, "W")
        cost_w = alg.match_cost(zone_west, row_west)
        cost_e = alg.match_cost(zone_east, row_west)
        self.assertLess(cost_w, cost_e, "Batı yönündeki bölge W hedefli satıra daha düşük maliyetle eşleşmeli")


if __name__ == "__main__":
    unittest.main()

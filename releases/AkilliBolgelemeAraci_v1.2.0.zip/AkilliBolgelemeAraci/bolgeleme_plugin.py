# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from .bolgeleme_dialog import BolgelemeDialog


class AkilliBolgelemePlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.svg')
        self.action = QAction(
            QIcon(icon_path),
            "Kentsel Bölgeleme ve Kırılganlık Analiz Aracı",
            self.iface.mainWindow()
        )
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("&Kentsel Bölgeleme Aracı", self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginVectorMenu("&Kentsel Bölgeleme Aracı", self.action)
            self.iface.removeToolBarIcon(self.action)
        if self.dialog:
            self.dialog.close()
            self.dialog = None

    def run(self):
        if self.dialog is None:
            self.dialog = BolgelemeDialog(self.iface, self.iface.mainWindow())
        self.dialog.auto_populate_all_layers()
        self.dialog.fit_to_screen()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()

# -*- coding: utf-8 -*-
"""QGIS'ten bağımsız saf-Python algoritma çekirdeği.

1) Mekansal Planlar Yapım Yönetmeliği (MPYY Madde 5) esaslarına göre arazi kullanımı ve donatı sınıflandırma
2) Mekânsal kısıtlı Ward birleştirme (yalnız KOMŞU hücreler birleşir)
3) Macar algoritması (parça <-> Excel gerekçe satırı eşleştirme)
4) Excel 'Aşama 1' gerekçe satırlarının sayısal profilleri
"""
import math
import re
import heapq

_TR = str.maketrans({"İ": "i", "I": "i", "ı": "i", "Ş": "s", "ş": "s", "Ğ": "g", "ğ": "g",
                     "Ü": "u", "ü": "u", "Ö": "o", "ö": "o", "Ç": "c", "ç": "c"})


def norm_tr(s):
    return str(s).translate(_TR).lower().strip()


LU_ORDER = ["sit", "sanayi", "tarim", "ticaret", "donati", "konut"]
LU_KEYS = {
    "sit": ("sit", "tescil", "tarihi", "anit", "koruma", "arkeolojik"),
    "sanayi": (
        "sanayi", "imalat", "fabrika", "depo", "atolye", "uretim", "lojistik", "osb",
        "kucuk sanayi", "endustri", "antrepo", "toplu isyer", "toptanci", "ambar", "hurda", "marangoz", "oto tamir"
    ),
    "tarim": (
        "tarim", "tarla", "bag", "bahce", "zeytin", "bos", "arsa", "ciftlik",
        "sera", "ziraat", "ahir", "mera", "ham", "ovasi", "cayir", "fidanlik"
    ),
    "ticaret": (
        "ticar", "dukkan", "magaza", "carsi", "market", "ofis", "banka", "otel", "lokanta",
        "restoran", "kafe", "cafe", "pazar", "is merkezi", "buro", "firin", "turizm", "konaklama",
        "alisveris", "avm", "oto galeri", "hizmet", "merkezi is", "mia"
    ),
    "donati": (
        "okul", "ilkokul", "ortaokul", "lise", "anaokul", "egitim", "kolej", "universite", "kurs", "yurt",
        "saglik", "hastane", "poliklinik", "dispanser", "asm", "aile saglik", "rehabilitasyon",
        "cami", "mescit", "ibadet", "dini", "kilise", "havra", "cemevi",
        "kultur", "kutuphane", "halk egitim", "sergi", "galeri", "muze", "konser", "konferans", "kongre", "sinema", "tiyatro", "opera",
        "sosyal", "kres", "cocuk yuvasi", "yetistirme", "bakimevi", "huzurevi", "sefkat", "toplum merkezi",
        "resmi", "idari", "kamu", "belediye", "hukumet", "kaymakamlik", "valilik", "muhtarlik", "karakol", "emniyet", "jandarma", "adliye",
        "itfaiye", "acil yardim", "kurtarma", "zabita", "mezbaha", "pazar yeri",
        "park", "cocuk bahcesi", "oyun alani", "meydan", "rekreasyon", "yesil", "spor", "stadyum", "halisaha", "kapali spor", "mezarlik",
        "teknik altyapi", "trafo", "aritma", "atik", "otopark", "garaj", "otogar", "terminal", "gar", "istasyon", "su deposu", "enerji", "donati"
    ),
    "konut": ("konut", "mesken", "apart", "villa", "ikamet", "yasam", "bitisik", "ev", "rezidans", "site", "lojm"),
}

ROAD_MEDIAN_WORDS = ("refuj", "kavsak", "ada", "gobek", "kaldirim", "yol", "agac", "orta refuj", "trafik")


def is_road_island_text(text):
    if not text:
        return False
    t = norm_tr(text)
    return any(w in t for w in ROAD_MEDIAN_WORDS)


def classify_landuse(text):
    if text is None:
        return {}
    t = norm_tr(text)
    if not t:
        return {}
    toks = re.findall(r"[a-z0-9]+", t)
    hit = []
    for cls in LU_ORDER:
        for key in LU_KEYS[cls]:
            if " " in key:
                ok = key in t
            elif key in ("ev", "bag", "bos", "ham", "gar", "asm", "mia", "avm"):
                ok = key in toks
            elif key == "sit":
                # "site", "sitesi", "siteler" yapı/sanayi yerleşkesi kelimelerini koruma sit alanı sayma
                ok = any(tok in ("sit", "siti", "sitler") or tok.startswith("sit-") for tok in toks)
            elif key in ("okul", "hastane", "depo", "spor", "park"):
                ok = any(key in tok for tok in toks)
            else:
                ok = any(tok.startswith(key) for tok in toks)
            if ok:
                hit.append(cls)
                break
    if not hit:
        return {"diger": 1.0}
    for strong in ("sit", "sanayi"):
        if strong in hit:
            return {strong: 1.0}
    w = 1.0 / len(hit)
    return {c: w for c in hit}


def median(v):
    s = sorted(v)
    n = len(s)
    if n == 0:
        return 0.0
    return s[n // 2] if n % 2 else 0.5 * (s[n // 2 - 1] + s[n // 2])


def zscore_columns(cols, clip=3.0):
    out, dropped = {}, []
    for k, v in cols.items():
        n = len(v)
        if n == 0:
            dropped.append(k)
            continue
        m = sum(v) / n
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / n)
        if sd < 1e-9:
            dropped.append(k)
            continue
        out[k] = [max(-clip, min(clip, (x - m) / sd)) for x in v]
    return out, dropped


def percentile_rank(values):
    n = len(values)
    if n <= 1:
        return [0.5] * n
    order = sorted(range(n), key=lambda i: values[i])
    ranks = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j + 1 < n and values[order[j + 1]] == values[order[i]]:
            j += 1
        r = (i + j) / 2.0 / (n - 1)
        for k in range(i, j + 1):
            ranks[order[k]] = r
        i = j + 1
    return ranks


def connect_components(adj, pts):
    n = len(pts)
    while True:
        comp = [-1] * n
        comps = []
        for s in range(n):
            if comp[s] != -1:
                continue
            cid = len(comps)
            stack, members = [s], []
            comp[s] = cid
            while stack:
                u = stack.pop()
                members.append(u)
                for v in adj[u]:
                    if comp[v] == -1:
                        comp[v] = cid
                        stack.append(v)
            comps.append(members)
        if len(comps) <= 1:
            return len(comps)
        small = min(comps, key=len)
        sc = comp[small[0]]
        best = None
        for u in small:
            for v in range(n):
                if comp[v] == sc:
                    continue
                d = (pts[u][0] - pts[v][0]) ** 2 + (pts[u][1] - pts[v][1]) ** 2
                if best is None or d < best[0]:
                    best = (d, u, v)
        adj[best[1]].add(best[2])
        adj[best[2]].add(best[1])


def ward_merge(vecs, node_w, areas, adj, target_k, area_cap=None, cap_pow=2.0, eps=0.05):
    n = len(vecs)
    dim = len(vecs[0]) if n else 0
    W = list(node_w)
    A = list(areas)
    V = [list(v) for v in vecs]
    members = {i: [i] for i in range(n)}
    nb = {i: set(adj[i]) for i in range(n)}
    ver = [0] * n
    alive = set(range(n))

    def cost(a, b):
        d2 = 0.0
        va, vb = V[a], V[b]
        for k in range(dim):
            d = va[k] - vb[k]
            d2 += d * d
        c = W[a] * W[b] / (W[a] + W[b]) * (d2 + eps)
        if area_cap:
            c *= 1.0 + ((A[a] + A[b]) / area_cap) ** cap_pow
        return c

    heap = []
    for a in range(n):
        for b in nb[a]:
            if a < b:
                heapq.heappush(heap, (cost(a, b), a, b, 0, 0))

    while len(alive) > target_k and heap:
        c, a, b, va, vb = heapq.heappop(heap)
        if a not in alive or b not in alive or ver[a] != va or ver[b] != vb:
            continue
        wa, wb = W[a], W[b]
        V[a] = [(wa * x + wb * y) / (wa + wb) for x, y in zip(V[a], V[b])]
        W[a] = wa + wb
        A[a] += A[b]
        members[a].extend(members.pop(b))
        alive.discard(b)
        nb[a] |= nb[b]
        nb[a].discard(a)
        nb[a].discard(b)
        for x in nb[b]:
            nb[x].discard(b)
            if x != a:
                nb[x].add(a)
        ver[a] += 1
        for x in nb[a]:
            heapq.heappush(heap, (cost(a, x), min(a, x), max(a, x), ver[min(a, x)], ver[max(a, x)]))

    labels = [0] * n
    for lab, root in enumerate(sorted(alive)):
        for m in members[root]:
            labels[m] = lab
    return labels


def hungarian(cost):
    n = len(cost)
    m = len(cost[0]) if n else 0
    if n > m:
        raise ValueError("satır sayısı sütun sayısını aşamaz")
    INF = float("inf")
    u = [0.0] * (n + 1)
    v = [0.0] * (m + 1)
    p = [0] * (m + 1)
    way = [0] * (m + 1)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minv = [INF] * (m + 1)
        used = [False] * (m + 1)
        while True:
            used[j0] = True
            i0 = p[j0]
            delta = INF
            j1 = 0
            for j in range(1, m + 1):
                if not used[j]:
                    cur = cost[i0 - 1][j - 1] - u[i0] - v[j]
                    if cur < minv[j]:
                        minv[j] = cur
                        way[j] = j0
                    if minv[j] < delta:
                        delta = minv[j]
                        j1 = j
            for j in range(m + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break
    res = [-1] * n
    for j in range(1, m + 1):
        if p[j]:
            res[p[j] - 1] = j - 1
    return res


_D = {"E": (1, 0), "W": (-1, 0), "N": (0, 1), "S": (0, -1),
      "NE": (0.707, 0.707), "NW": (-0.707, 0.707), "SE": (0.707, -0.707), "SW": (-0.707, -0.707)}

EXCEL_ROWS = [
    ("A1", "Konut (Düşük Yoğunluk) / Çeper", "Batıdaki düşük yoğunluklu evlerin ve boş arsaların olduğu geçiş bölgesi.", {"dens": .2, "merkez": .3, "konut": .6}, "W"),
    ("A2", "Konut (Orta Yoğunluk)", "Merkez ile çeperin arasında kalan, standart orta yoğunluklu konutların bulunduğu mahalle.", {"dens": .5, "merkez": .5, "konut": .7}, None),
    ("A3", "Karma Kullanım (Ticaret + Konut)", "Planın tam merkezine yakın, dükkan ve evlerin (karma kullanım) iç içe olduğu canlı aks.", {"karma": .8, "merkez": .8, "dens": .7}, None),
    ("A4", "Konut (Bitişik Nizam)", "Bitişik nizamlı, orta-yüksek katlı evlerin yer aldığı geleneksel parsel dokusu.", {"konut": .7, "kat": .7, "dens": .7, "bitisik": .8}, None),
    ("A5", "Ticaret - Konut - Resmi Kurum", "Ticaret ve resmi yapıların evlerle karıştığı, hareketli bir merkez geçişi.", {"ticaret": .4, "konut": .4, "donati": .7, "merkez": .7}, None),
    ("A6", "Ticaret Alanı (Çarşı/Merkez)", "Dükkanların, mağazaların ve insan kalabalığının yoğun olduğu ticaret aksı.", {"ticaret": .8, "merkez": .9, "dens": .8}, None),
    ("A7", "Şehir Merkezi / Tarihi Sit Alanı", "Şehir merkezi ve tarihi sit alanı, tescilli binaların yer aldığı en hassas bölge.", {"sit": .9, "merkez": .9, "ticaret": .3}, None),
    ("A8", "Merkezi Ticaret Dokusu", "Dar sokaklı, küçük dükkanların ve ticari yapıların bulunduğu merkez bölgesi.", {"ticaret": .6, "merkez": .9, "dens": .9}, None),
    ("A9", "Konut (Mahalle Dokusu)", "Konut ağırlıklı olan, dışarıdaki boş alanlara açılan mahalle dokusu.", {"konut": .7, "dens": .4, "merkez": .4}, None),
    ("A10", "Gelişme Konut Alanı", "Doğuya doğru yeni büyüyen, yeni evlerin yapılmaya başlandığı konut bölgesi.", {"konut": .6, "dens": .25, "merkez": .35}, "E"),
    ("A11", "Karma Kullanım", "Hem dükkanların hem evlerin olduğu, orta büyüklükteki adalardan oluşan ara bölge.", {"karma": .6, "dens": .6, "merkez": .6}, None),
    ("A12", "Konut (Geçiş Dokusu)", "Eski kent dokusu ile yeni binalar arasında kalan konut adaları.", {"konut": .7, "dens": .6, "merkez": .6}, None),
    ("A13", "Konut / Seyrek Yapılaşma", "Doğu taraftaki, alçak katlı evlerin ve boş parsellerin olduğu alan.", {"konut": .6, "dens": .3, "kat": .2}, "E"),
    ("A14", "Konut (Düzenli Parselasyon)", "Batıdaki ana yollarla çevrili, düzenli sokaklara sahip konut bölgesi.", {"konut": .8, "dens": .6, "merkez": .6}, "W"),
    ("A15", "Konut / Arsa (Giriş Çeperi)", "Güneybatı girişinde yer alan, düşük yoğunluklu evlerin ve arsaların bulunduğu çeper.", {"konut": .5, "dens": .2, "tarim": .2, "merkez": .4}, "SW"),
    ("A16", "Tarım Alanı / Çeper Doku", "Doğudaki geniş tarım arazilerinin ve seyrek yapıların olduğu tarımsal çeper.", {"tarim": .9, "dens": .05, "merkez": .1}, "E"),
    ("A17", "Konut (Eğimli Topoğrafya)", "Güneydoğuda hafif eğimin başladığı, düşük yoğunluklu konut alanı.", {"konut": .5, "egim": .7, "dens": .25}, "SE"),
    ("A18", "Doğal Eşik / Dere Çeperi", "En güneydoğuda, dere yataklarına yakın ve doğal eşiklerle sınırlanan yerleşim.", {"dere": .9, "dens": .3, "egim": .6}, "SE"),
    ("A19", "Karma Kullanım / Sit Çeperi", "Tarihi merkezin güneyinde, sit alanına komşu olan karma kullanım bölgesi.", {"karma": .6, "sit": .4, "dens": .7}, "S"),
    ("A20", "Kentsel-Kırsal Geçiş (Ekoton)", "Güneybatı sınırında, tarla ve evlerin bir arada görüldüğü geçiş alanı.", {"tarim": .4, "konut": .3, "dens": .15, "merkez": .15}, "SW"),
    ("A21", "Kuzey Koridoru / Depolama", "Kuzeydeki ana yollarla tarım alanları arasında kalan, depoların da görüldüğü kuzey koridoru.", {"sanayi": .4, "tarim": .4, "dens": .1}, "N"),
    ("A22", "Dere Çeperi Yerleşimi", "En güneyde dere kenarında ve topografyaya dayanan çeper yerleşimi.", {"dere": .9, "egim": .6, "dens": .4}, "S"),
    ("A23", "Tarım - Konut Hassas Doku", "Güney sınır hattı boyunca uzanan, tarım ve konut dokusunun karıştığı hassas parsel yapısı.", {"tarim": .3, "konut": .5, "dens": .5}, "S"),
    ("A24", "Ticaret - Konut Yoğun Doku", "Güney merkezde ticaret ve konutun yoğun olarak iç içe geçtiği doku.", {"ticaret": .5, "konut": .5, "dens": .8, "merkez": .8}, "S"),
    ("A25", "Konut ve Sosyal Donatı", "Batı güney kesiminde yer alan, mahalle içi evlerin ve donatıların olduğu ada.", {"konut": .7, "donati": .7, "dens": .6}, "SW"),
    ("A26", "Kentsel Çeper / Kırsal Sınır", "Sınırın en güney ucunda, doğaya ve kırsal sınıra oturan çeper bölgesi.", {"dens": .3, "egim": .7, "merkez": .1}, "S"),
    ("A27", "Tarihi / Ticari Hassas Doku", "Tarihi ve ticari odakların kesiştiği, dar sokaklı hassas ticaret ve konut alanı.", {"sit": .6, "ticaret": .6, "dens": .9, "merkez": .8}, None),
    ("A28", "Sanayi / Depolama Alanı (OSB)", "Sanayi alanı, küçük sanayi siteleri ve depoların toplandığı kuzeybatıdaki çalışma bölgesi.", {"sanayi": .95, "dens": .2}, "NW"),
]

FEATURE_W = {"sanayi": 2.5, "tarim": 1.5, "sit": 2.0, "dere": 1.5}

ADVANCED_PROFILES = [
    ("M1", "Tarihi MİA ve Arasta Ticaret Çekirdeği",
     "Yoğun yaya akışı, tescilli kültürel miras ve zemin ticaretinin odaklandığı geleneksel merkez.",
     {"merkez": .9, "ticaret": .8, "sit": .5}, None,
     "Yüksek yaya akışı + yoğun zemin ticaret + tescilli kültür varlıkları + dar sokak profili + düşük yeşil alan",
     "Yayalaştırma ve trafik sakinleştirme, tarihi cephe sağlıklaştırma, meydan ve gölgeli dinlenme alanları oluşturma",
     "1/5000 NİP: Merkezi İş Alanı (MİA) ve Kentsel Sit Tamponu; 1/1000 UİP: Yaya yolları, zemin ticaret + üst kat konut karma kullanımı, koruma amaçlı imar planı notu"),

    ("M2", "Kuzey Fay Hattı ve Yüksek Yoğunluklu Afet Kuşağı",
     "Diri fay hattı tamponu, zemin sıvılaşma riski ve yüksek yoğunluklu yapı dokusunun kesiştiği tehlike eşiği.",
     {"fay": .9, "dens": .8, "kat": .8}, "N",
     "Diri fay hattı tamponu + zemin sıvılaşma riski + yüksek katlı yapı stoku + yetersiz açık toplanma alanı",
     "Yapılaşma yasağı ve seyreltme tamponu, acil afet toplanma ve çadır kent alanı tahsisi, tahliye koridoru açılması",
     "1/5000 NİP: Afet Tehlikeli Alan ve Açık Yeşil Alan Kuşağı; 1/1000 UİP: TAKS/KAKS düşürme, yapı yaklaşma sınırı, afet toplanma alanı lejantı"),

    ("M3", "Demiryolu İstasyonu ve Lojistik Geçiş Kuşağı",
     "Raylı sistem erişimi, transit aktarma potansiyeli ve konut-sanayi arayüzünün oluşturduğu kentsel koridor.",
     {"sanayi": .4, "merkez": .6, "dens": .5}, None,
     "Demiryolu hattı ve istasyon erişimi + lojistik depolama talebi + konut-sanayi geçiş arayüzü",
     "Transit Odaklı Gelişim (TOD), istasyon meydanı düzenlemesi, yaya/bisiklet üst geçitleri ve gürültü perdesi",
     "1/5000 NİP: Ulaşım ve Transfer Merkezi; 1/1000 UİP: İstasyon meydanı, otopark, lojistik servis yolu ve yeşil tampon"),

    ("M4", "Sanayi - Konut Hassas Tampon Arayüzü",
     "Sanayi çalışma alanları ile konut yerleşimlerinin sınır temasında yer alan çevresel baskı kuşağı.",
     {"sanayi": .7, "konut": .3, "dens": .4}, "NW",
     "Sanayi ve depolama kullanımı + konut yerleşimi komşuluğu + yetersiz koruma bandı + hava/gürültü emisyonu",
     "Kesintisiz koruyucu yeşil kuşak/tampon oluşturulması, ağır vasıta güzergâhının konut içinden arındırılması",
     "1/5000 NİP: Sanayi Koruma Tamponu; 1/1000 UİP: 25-50 metre genişliğinde ağaçlandırılacak alan ve lojistik çevre yolu"),

    ("M5", "Küçük Menderes Taşkın Yatağı ve Ekolojik Tarım Kuşağı",
     "Yüksek sel/taşkın riski, 1. sınıf mutlak tarım toprağı ve düşük topoğrafik rakımın belirlediği koruma alanı.",
     {"tarim": .9, "dere": .9, "dens": .05}, "E",
     "Taşkın risk alanı (HAND/TWI) + dere yatağı komşuluğu + mutlak tarım arazisi + düşük zemin kotu",
     "Kesin yapılaşma yasağı, doğal taşkın yatağı koruma ve ekolojik koridor düzenlemesi, tarımsal niteliğin korunması",
     "1/5000 NİP: Ekolojik Koridor ve Tarımsal Koruma Alanı; 1/1000 UİP: Yapı yapılamaz taşkın sınırı ve rekreasyon alanı"),

    ("M6", "Akçeşme Deresi Koridoru ve Yeşil Altyapı Omurgası",
     "Kentsel alan boyunca uzanan dere yatağı, taşkın kısıtı ve kesintisiz açık-yeşil alan potansiyeli.",
     {"dere": .95, "egim": .4, "dens": .3}, "S",
     "Dere koridoru + doğal drenaj hattı + kentsel gecekondulaşma/yapılaşma baskısı",
     "Dere yatağı ıslahı, kesintisiz yaya-bisiklet yeşil omurgası, dere koruma bandı çekme mesafesi uygulanması",
     "1/5000 NİP: Doğal Yeşil Koridor; 1/1000 UİP: Dere koruma kuşağı, aktif yeşil alan ve bisiklet yolu"),

    ("M7", "Eğimli Yamaç Kentsel Gelişme ve Manzara Dokusu",
     "Yüksek topoğrafik eğim, manzara ve siluet etkisi taşıyan düşük yoğunluklu yamaç konut yerleşimi.",
     {"egim": .8, "konut": .6, "dens": .3}, "SE",
     "Yüksek eğim (>%15) + yüksek rakım kotu + gevşek zemin yapısı + siluet etkisi",
     "Kademeli azalan yoğunluk, teraslama, jeolojik drenaj önlemleri, kentsel siluet koruma ilkeleri",
     "1/5000 NİP: Düşük Yoğunluklu Konut Gelişme Alanı; 1/1000 UİP: Gabari (Hmax) sınırlaması, eğimli yol kesitleri ve kademeli nizam"),

    ("M8", "Toplu Konut ve Donatı Yetersizliği Odak Alanı",
     "Hızlı nüfus yığılması, 2SFCA donatı erişim açığı ve ısı adası baskısının yoğunlaştığı konut bölgesi.",
     {"dens": .8, "kat": .8, "donati": .2}, None,
     "Yüksek kat ve nüfus yoğunluğu + okul/sağlık erişim açığı + yüksek LST yüzey sıcaklığı + otopark yetersizliği",
     "Yeni sosyal ve teknik donatı alanı tahsisi, mahalle parkı ve gölgelendirme, otopark cepleri organizasyonu",
     "1/5000 NİP: Sosyal Donatı ve Kentsel Servis Odakları; 1/1000 UİP: İlkokul, aile sağlığı merkezi, kreş ve otopark alanı"),

    ("M9", "Kentsel-Kırsal Geçiş ve Eko-Turizm Çeperi",
     "Kentsel saçaklanma sınırında yer alan, geleneksel bağ/bahçe ve tarımsal kimliğini koruyan ekoton alanı.",
     {"tarim": .6, "konut": .3, "dens": .15}, "SW",
     "Kentsel saçaklanma sınırı + kırsal yerleşim mirası + bahçe ve tarım parselleri",
     "Köy yerleşik alan sınırının korunması, tarımsal parçalanmanın önlenmesi, agro-turizm ve kırsal tesis desteği",
     "1/5000 NİP: Kentsel-Kırsal Geçiş (Ekoton) ve Eko-Turizm Kuşağı; 1/1000 UİP: Kırsal turizm ve tarımsal depo plan notu"),

    ("M10", "Arkeolojik ve Tarihi Sit Koruma Tamponu",
     "Tescilli anıt eserler, arkeolojik kalıntılar ve kentsel sit alanı koruma kuşağı.",
     {"sit": .95, "merkez": .8, "dens": .5}, None,
     "Arkeolojik/kentsel sit sınırları + tescilli yapı yoğunluğu + yapılaşma baskısı",
     "Kültürel miras koruma ve restorasyon programı, sit tampon bölgesi oluşturma, kültür rotası ve ziyaretçi yönetimi",
     "1/5000 NİP: Tarihi ve Arkeolojik Sit Alanı; 1/1000 UİP: Koruma Amaçlı İmar Planı (KAİP) hükümleri"),

    ("M11", "Sosyo-Mekânsal Kırılganlık ve Kentsel Yenileme Odak Alanı",
     "Kötü yapı kalitesi, dar sokak dokusu ve kentsel yoksunluk göstergelerinin birleştiği öncelikli dönüşüm alanı.",
     {"dens": .7, "bitisik": .8, "donati": .3}, None,
     "Kötü durumdaki yapı oranı >%40 + dar ve çıkmaz sokaklar + yüksek nüfus yoğunluğu + yetersiz altyapı",
     "Yerinde kentsel sağlıklaştırma ve dönüşüm, sokak genişletme, sosyal tesis ve yeşil donatı kazandırma",
     "1/5000 NİP: Kentsel Yenileme ve Sağlıklaştırma Alanı; 1/1000 UİP: Dönüşüm etaplama sınırı ve donatı rezervi"),

    ("M12", "Ulaşım Transfer Kavşağı ve Çevre Yolu Servis Aksı",
     "Bölgesel karayolu bağlantısı, otogar tesisi ve ağır transit trafiğin yarattığı parçalanma eşiği.",
     {"sanayi": .4, "merkez": .5, "dens": .4}, "W",
     "Çevre yolu ve kavşak omurgası + otogar/terminal tesisi + transit ticari depolama",
     "Katlı veya dönel kavşak geometrik düzenlemesi, lojistik park ve transfer alanı, gürültü perdesi ağaçlandırması",
     "1/5000 NİP: Bölgesel Ulaşım ve Lojistik Terminali; 1/1000 UİP: Kavşak koruma kuşağı ve otopark alanı"),

    ("M13", "Eğitim Kampüsü ve Gençlik Hareketlilik Çekirdeği",
     "Yükseköğretim ve ortaöğretim kümelenmesi, yaya/bisiklet hareketliliği ve genç nüfus odaklı hizmet aksı.",
     {"donati": .8, "merkez": .6, "dens": .6}, None,
     "Eğitim tesisleri yoğunluğu + yurt ve öğrenci konutu talebi + genç odaklı kafeterya ve ticaret",
     "Güvenli okul yolları, bisiklet şebekesi entegrasyonu, öğrenci barınma ve karma kullanım koridoru",
     "1/5000 NİP: Eğitim ve Üniversite Gelişme Alanı; 1/1000 UİP: Karma kullanım (öğrenci konutu + ticaret) ve bisiklet yolu"),

    ("M14", "Kentsel Mezarlık ve Açık Yeşil Tampon Kuşağı",
     "Kentsel mezarlık alanı, dini tesis ve çevresindeki yeşil koruma kuşağı.",
     {"tarim": .4, "donati": .6, "dens": .2}, "S",
     "Mezarlık alanı + çevresindeki kontrolsüz konut yapılaşması baskısı + yeşil doku sürekliliği",
     "Mezarlık koruma ve genişleme bandı oluşturulması, çevresinde yeşil tampon ağaçlandırması",
     "1/5000 NİP: Mezarlık ve Yeşil Tampon; 1/1000 UİP: Ağaçlandırılacak alan ve koruma kuşağı"),

    ("M15", "Yüksek Gerilim Altyapı Güvenlik ve Enerji Koridoru",
     "Yüksek gerilim enerji nakil hatları (ENH), trafo sahası ve manyetik alan güvenlik koridoru.",
     {"tarim": .5, "sanayi": .3, "dens": .1}, "NW",
     "Yüksek gerilim hattı koridoru + trafo sahası + altındaki kontrolsüz parselasyon",
     "Hat altı yapı yasağı uygulanması, pasif yeşil koridor ve tarımsal açık alan olarak sürekliliğin sağlanması",
     "1/5000 NİP: Teknik Altyapı Güvenlik Kuşağı; 1/1000 UİP: ENH koruma bandı ve pasif yeşil alan"),

    ("M16", "Toptancı Hal, Semt Pazarı ve Gıda Dağıtım Merkezi",
     "Kentsel gıda tedariki, semt pazarı sirkülasyonu ve servis trafiğinin yoğunlaştığı ticaret alanı.",
     {"ticaret": .7, "sanayi": .3, "dens": .5}, None,
     "Pazar yeri alanı + tarımsal üretim havzası girişi + kamyon-servis araç trafiği + atık baskısı",
     "Modern kapalı pazar yeri ve soğuk hava depolama lojistiği, yükleme-boşaltma cepleri, geri dönüşüm ve otopark",
     "1/5000 NİP: Kentsel Servis ve Toptan Ticaret Alanı; 1/1000 UİP: Kapalı pazar yeri, otopark ve altyapı tesisi"),

    ("M17", "Kırsal Bağ ve Gastronomi Turizm Güzergâhı",
     "Geleneksel tarımsal peyzaj, bağ rotaları ve yerel üretim odaklı kırsal turizm potansiyeli.",
     {"tarim": .7, "egim": .5, "dens": .1}, "SE",
     "Bağ ve bahçe parselleri + geleneksel taş yapı dokusu + manzara ve yürüyüş rotaları",
     "Kırsal peyzajın spekülasyondan korunması, butik bağ rotası, bisiklet ve yürüyüş patikaları düzenlemesi",
     "1/5000 NİP: Kırsal Turizm ve Doğal Karakteri Korunacak Alan; 1/1000 UİP: Agro-turizm ve kırsal pansiyon plan notu"),

    ("M18", "Kent Ormanı, Mesire ve Yangın Önleme Kuşağı",
     "Kentsel rekreasyon, yamaç orman varlığı ve orman yangını önleme tampon hattı.",
     {"egim": .8, "tarim": .4, "dens": .05}, "S",
     "Orman alanı + güney yamaç eğimi + kentli dinlenme talebi + orman yangını hassasiyeti",
     "Kontrollü mesire alanı yönetimi, orman-kent arayüzünde yangın emniyet şeridi ve su ikmal noktaları",
     "1/5000 NİP: Orman ve Bölgesel Park; 1/1000 UİP: Mesire yeri, yangın şeridi ve teknik altyapı"),

    ("M19", "Geleneksel Çarşı ve Karma Ticaret Omurgası",
     "Dar sokak dokusuna sahip zemin ticaret ve konut karma aksı.",
     {"ticaret": .8, "merkez": .8, "karma": .7}, None,
     "Tarihi ticaret aksı + yaya yoğunluğu + servis araçları çatışması",
     "Trafik sakinleştirme, yayalaştırma saatleri, kentsel mobilya ve cephe düzenlemesi",
     "1/5000 NİP: Ticaret-Konut Karma Alanı; 1/1000 UİP: TİCK ve yaya öncelikli yol"),

    ("M20", "Düzenli İmar Parselasyonlu Konut Dokusu",
     "Geniş yol profilleri ve ayrık nizamlı konut bloklarının bulunduğu düzenli gelişme dokusu.",
     {"konut": .8, "dens": .5, "merkez": .5}, "W",
     "Düzenli ada formu + standart TAKS/KAKS + orta yoğunluklu konut",
     "Mevcut morfolojik nizamın korunması, yeşil ada içi avluların güçlendirilmesi",
     "1/5000 NİP: Orta Yoğunluklu Yerleşik Konut; 1/1000 UİP: Ayrık nizam konut adaları"),

    ("M21", "Seyrek Dokulu Kırsal Yerleşim Çeperi",
     "Geniş bahçeli evler ve tarımsal üretim alanlarının iç içe geçtiği seyrek yerleşim.",
     {"tarim": .8, "dens": .1}, "E",
     "Seyrek yapı dokusu + tarımsal açık alanlar + düşük altyapı maliyeti",
     "Düşük emsalli kırsal konut koşulu, tarım arazilerinin korunması",
     "1/5000 NİP: Kırsal Nitelikli Konut Alanı; 1/1000 UİP: E=0.20 kırsal konut"),

    ("M22", "Dere Kenarı Kentsel Dönüşüm ve Park Alanı",
     "Dere yatağına komşu, taşkın hassasiyeti bulunan ve dönüşüm bekleyen yapı dokusu.",
     {"dere": .8, "dens": .5, "egim": .4}, "S",
     "Dere yakınlığı + taşkın maruziyeti + eski yapı stoku",
     "Dere cephesi yapıların tasfiyesi, taşkın koruma bendi ve lineer park yapımı",
     "1/5000 NİP: Taşkın Önlemli Kentsel Yeşil Koridor; 1/1000 UİP: Rekreasyon ve park"),

    ("M23", "Organize Sanayi Bölgesi (TOSB) Çekirdeği",
     "Büyük parselasyonlu imalat sanayisi ve lojistik tesislerin toplandığı üretim odağı.",
     {"sanayi": .95, "dens": .2}, "NW",
     "Ağır sanayi üretimi + tehlikeli madde depolama + demiryolu lojistiği",
     "Arıtma tesisi zorunluluğu, OSB içi itfaiye ve acil müdahale istasyonu tahsisi",
     "1/5000 NİP: Organize Sanayi Bölgesi; 1/1000 UİP: Sanayi ve depolama alanı"),

    ("M24", "Karma Kullanımlı Kentsel Sağlıklaştırma Kuşağı",
     "Konut ve küçük esnaf dükkanlarının iç içe girdiği geçiş dokusu.",
     {"karma": .7, "dens": .6, "merkez": .6}, None,
     "Karma fonksiyonlar + orta kat yüksekliği + otopark ihtiyacı",
     "Zemin kat ticari standartları, otopark cepleri, cephe tipolojisi",
     "1/5000 NİP: Karma Kullanım Alanı; 1/1000 UİP: Konut+Ticaret karma adaları"),

    ("M25", "Yeni Kentsel Gelişme ve Rezerv Konut Alanı",
     "Kentin büyüme aksında yer alan, planlı altyapı bekleyen boş imar adaları.",
     {"konut": .7, "dens": .3}, "E",
     "Boş imar adaları + yeni konut talebi + altyapı koridoru",
     "Etaplı kentsel gelişme, enerji verimli bina tasarımı, bisiklet altyapısı",
     "1/5000 NİP: Kentsel Gelişme Alanı; 1/1000 UİP: Yeni konut yerleşimi"),

    ("M26", "Mahalle İçi Sosyal Altyapı ve Donatı Kümesi",
     "Eğitim, sağlık ve dini tesislerin çevrelediği sosyal odak noktası.",
     {"donati": .7, "konut": .6, "dens": .5}, "SW",
     "Kamu tesisleri varlığı + yaya erişimi + mahalle merkezi niteliği",
     "Yaya öncelikli çevre düzenlemesi, güvenli okul bölgesi, engelsiz erişim",
     "1/5000 NİP: Sosyal ve Kültürel Tesis Alanı; 1/1000 UİP: Donatı adaları"),

    ("M27", "Tarihi Doku - Sit Çeperi Tampon Arayüzü",
     "Tarihi sit sınırının hemen dışındaki geçiş bölgesi.",
     {"sit": .6, "karma": .5, "merkez": .7}, None,
     "Sit komşuluğu + siluet etkisi + turizm baskısı",
     "Sit uyumlu kat ve gabari kısıtlaması, geleneksel malzeme zorunluluğu",
     "1/5000 NİP: Sit Etkileşim-Geçiş Sahası; 1/1000 UİP: Koruma geçiş plan notu"),

    ("M28", "Topoğrafik Eşik ve Doğal Sınır Kuşağı",
     "Yerleşimin sonlandığı, yüksek eğimli ve kayalık doğal sınır.",
     {"egim": .7, "dens": .2}, "S",
     "Yüksek eğim (>%20) + kısıtlı ulaşım + kentsel eşik",
     "Yerleşme sınırı çekilmesi, erozyon kontrolü ve ağaçlandırma",
     "1/5000 NİP: Doğal Eşik / Ağaçlandırılacak Alan; 1/1000 UİP: İmar dışı doğal alan"),
]


def match_cost(zone, row):
    _, _, _, targets, direction = row[:5]
    num = den = 0.0
    for k, t in targets.items():
        z = zone.get(k)
        if z is None:
            continue
        w = FEATURE_W.get(k, 1.0)
        num += w * (z - t) ** 2
        den += w
    cost = num / den if den else 0.5
    if direction:
        zd = zone.get("dir")
        if zd is None:
            dterm = 0.25
        else:
            tx, ty = _D[direction]
            dterm = (1.0 - (zd[0] * tx + zd[1] * ty)) / 2.0
        cost += 0.35 * dterm
    return cost


def match_zones_to_rows(zone_feats, mode="standard"):
    n = len(zone_feats)
    rows = ADVANCED_PROFILES if mode == "advanced" else EXCEL_ROWS
    m = len(rows)
    if n > m:
        raise ValueError("parça sayısı profil satırlarından fazla")
    cost = [[match_cost(z, r) for r in rows] for z in zone_feats]
    assign = hungarian(cost)
    out = []
    for i, j in enumerate(assign):
        out.append((j, round(max(0.0, 100.0 * (1.0 - cost[i][j] / 0.6)), 1)))
    return out

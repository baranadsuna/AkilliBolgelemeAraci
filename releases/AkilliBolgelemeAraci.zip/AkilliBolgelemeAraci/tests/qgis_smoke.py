# -*- coding: utf-8 -*-
r"""Akıllı Bölgeleme Aracı - Gerçek QGIS Uçtan Uca (E2E) Duman Testi (Başsız / Headless).

Çalıştırma (OSGeo4W):
  C:\OSGeo4W\bin\python-qgis.bat -u tests\qgis_smoke.py

Sentetik Veri Seti:
  Yerel Projeksiyon EPSG:5253 (TUREF / GK Zone 27 / İzmir).
  - Yol ağı (çizgiler: genişlik, kaplama, kademe)
  - İmar adaları (poligonlar: konut, ticaret, sanayi, tarım, sit)
  - Opsiyonel tekil yapılar (binalar: kat, nizam, durum, nüfus)
  - Doğal eşikler: Dere, Diri Fay, Sit / Tescil, Taşkın Risk Alanı, Donatı
  - DEM (GeoTIFF yükseklik modeli)

Tüm analiz fonksiyonları, Kural 1-5 algoritmaları, GUI kontrolleri ve
eklenti yaşam döngüsü doğrulanır.
"""

import csv
import math
import os
import struct
import sys
import tempfile
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
PLUGIN_ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(PLUGIN_ROOT))

from qgis.core import (
    QgsApplication, QgsCoordinateReferenceSystem, QgsFeature, QgsGeometry,
    QgsPointXY, QgsProject, QgsRasterLayer, QgsVectorLayer, QgsWkbTypes
)

QgsApplication.setPrefixPath(os.environ.get("QGIS_PREFIX_PATH", ""), True)
APP = QgsApplication([], False)
APP.initQgis()

FAILS = []


def _hook(exc_type, exc, tb):
    traceback.print_exception(exc_type, exc, tb)
    FAILS.append("yuva hatası: %s" % exc)


sys.excepthook = _hook


def check(cond, msg):
    status = "  ok   " if cond else "  FAIL "
    print(status + msg)
    sys.stdout.flush()
    if not cond:
        FAILS.append(msg)


def mem_layer(geom_type, fields, rows, name, crs_str="EPSG:5253"):
    field_defs = "&".join("field=%s" % f for f in fields)
    uri = "%s?crs=%s&%s" % (geom_type, crs_str, field_defs)
    lyr = QgsVectorLayer(uri, name, "memory")
    feats = []
    for wkt, attrs in rows:
        f = QgsFeature(lyr.fields())
        f.setGeometry(QgsGeometry.fromWkt(wkt))
        f.setAttributes(attrs)
        feats.append(f)
    lyr.dataProvider().addFeatures(feats)
    lyr.updateExtents()
    return lyr


def make_dem_raster(path, crs_epsg=5253):
    from osgeo import gdal, osr
    gdal.UseExceptions()
    drv = gdal.GetDriverByName("GTiff")
    # 40 x 30 hücre, her hücre 10 m
    # Sol-üst köşe: x=500000.0, y=4250300.0
    ds = drv.Create(path, 40, 30, 1, gdal.GDT_Float32)
    ds.SetGeoTransform((500000.0, 10.0, 0, 4250300.0, 0, -10.0))
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(crs_epsg)
    ds.SetProjection(srs.ExportToWkt())
    band = ds.GetRasterBand(1)
    for r in range(30):
        # Doğuya ve güneye doğru artan eğim profili (10 m -> 100 m)
        row = [10.0 + c * 1.5 + (30 - r) * 1.0 for c in range(40)]
        band.WriteRaster(0, r, 40, 1, struct.pack("40f", *row))
    band.SetNoDataValue(-9999)
    ds.FlushCache()
    ds = None


class FakeIface:
    """QGIS başsız test arayüz taklitçisi."""
    def __init__(self):
        from qgis.PyQt.QtWidgets import QMainWindow
        self.win = QMainWindow()
        self.icons = []
        self.menus = []

    def mainWindow(self):
        return self.win

    def addToolBarIcon(self, a):
        self.icons.append(a)

    def removeToolBarIcon(self, a):
        if a in self.icons:
            self.icons.remove(a)

    def addPluginToVectorMenu(self, name, a):
        self.menus.append((name, a))

    def removePluginVectorMenu(self, name, a):
        self.menus = [(m, act) for m, act in self.menus if act != a]

    def mapCanvas(self):
        class FakeCanvas:
            def refresh(self):
                pass
        return FakeCanvas()


def main():
    print("=" * 80)
    print("AKILLI BÖLGELEME ARACI - E2E DUMAN TESTLERİ (EPSG:5253)")
    print("=" * 80)

    # 1. Sentetik Katmanların Hazırlanması
    # Çalışma alanı: [500000, 4250000] - [500400, 4250300] (400 m x 300 m)
    bnd = mem_layer(
        "Polygon", ["ad:string"],
        [("POLYGON((500000 4250000, 500400 4250000, 500400 4250300, 500000 4250300, 500000 4250000))", ["Calisma_Alani"])],
        "plan_siniri"
    )
    check(bnd.isValid() and bnd.featureCount() == 1, "Plan sınırı katmanı oluşturuldu")

    # Yol Ağı (3 yatay, 3 dikey çizgi ile ızgara yol ağı)
    road_rows = [
        # Dikey yollar
        ("LINESTRING(500100 4250000, 500100 4250300)", [15.0, "Asfalt", "Cadde"]),
        ("LINESTRING(500200 4250000, 500200 4250300)", [12.0, "Asfalt", "Cadde"]),
        ("LINESTRING(500300 4250000, 500300 4250300)", [8.0, "Parke", "Sokak"]),
        # Yatay yollar
        ("LINESTRING(500000 4250100, 500400 4250100)", [14.0, "Asfalt", "Cadde"]),
        ("LINESTRING(500000 4250200, 500400 4250200)", [10.0, "Parke", "Sokak"]),
        # Yol refüjü adacığı (filtre testleri için çok ince poligon)
        ("LINESTRING(500105 4250010, 500105 4250090)", [4.0, "Toprak", "Refuj"]),
    ]
    roads = mem_layer("LineString", ["genislik:double", "kaplama:string", "kademe:string"], road_rows, "yol_agi")
    check(roads.isValid() and roads.featureCount() == 6, "Yol ağı katmanı oluşturuldu")

    # İmar Adaları:
    # Ada 1 (0,0)-(100,100): Konut Alanı (Bitişik, 4 kat, nufus=400)
    # Ada 2 (100,0)-(200,100): Ticaret Alanı (Ayrık, 3 kat, nufus=150)
    # Ada 3 (200,0)-(300,100): Sanayi / OSB (Ayrık, 1 kat, nufus=0 -> Kural 1 testi)
    # Ada 4 (300,0)-(400,100): Tarım / Açık Alan (Seyrek, nufus=0 -> Kural 1 testi)
    # Ada 5 (0,100)-(100,200): Sit / Koruma Alanı (Tescilli binalar)
    # Ada 6 (100,100)-(200,200): Donatı / Hastane
    # Ada 7 (200,100)-(300,200): Konut (Orta yoğunluk)
    # Ada 8 (300,100)-(400,200): Tarım / Kırsal
    # Refüj poligonu: çok dar ada (filtre testi)
    block_rows = [
        ("POLYGON((500010 4250010, 500090 4250010, 500090 4250090, 500010 4250090, 500010 4250010))",
         ["Konut Alanı", 4.0, "Bitişik", "İyi", 400.0]),
        ("POLYGON((500110 4250010, 500190 4250010, 500190 4250090, 500110 4250090, 500110 4250010))",
         ["Ticaret Alanı", 3.0, "Ayrık", "Orta", 150.0]),
        ("POLYGON((500210 4250010, 500290 4250010, 500290 4250090, 500210 4250090, 500210 4250010))",
         ["Sanayi / OSB Alanı", 1.0, "Ayrık", "Orta", 0.0]),
        ("POLYGON((500310 4250010, 500390 4250010, 500390 4250090, 500310 4250090, 500310 4250010))",
         ["Tarım / Zeytinlik", 1.0, "Seyrek", "İyi", 0.0]),
        ("POLYGON((500010 4250110, 500090 4250110, 500090 4250190, 500010 4250190, 500010 4250110))",
         ["Tarihi Sit Alanı", 2.0, "Bitişik", "Tarihi", 50.0]),
        ("POLYGON((500110 4250110, 500190 4250110, 500190 4250190, 500110 4250190, 500110 4250110))",
         ["Sosyal Donatı / Okul", 2.0, "Ayrık", "İyi", 0.0]),
        ("POLYGON((500210 4250110, 500290 4250110, 500290 4250190, 500210 4250190, 500210 4250110))",
         ["Konut Alanı", 5.0, "Ayrık", "Kötü/Hasarlı", 600.0]),
        ("POLYGON((500310 4250110, 500390 4250110, 500390 4250190, 500310 4250190, 500310 4250110))",
         ["Tarım / Çiftlik", 1.0, "Seyrek", "Orta", 0.0]),
        # Refüj poligonu (kalınlık 2 m -> süzülmeli)
        ("POLYGON((500101 4250020, 500103 4250020, 500103 4250080, 500101 4250080, 500101 4250020))",
         ["Orta Refüj", 0.0, "Yok", "Yok", 0.0]),
    ]
    blocks = mem_layer("Polygon", ["kullanim:string", "kat:double", "yd:string", "durum:string", "nufus:double"],
                       block_rows, "imar_adalari")
    check(blocks.isValid() and blocks.featureCount() == 9, "İmar adaları katmanı oluşturuldu")

    # Tekil Yapılar (Opsiyonel bina stoku)
    bldg_rows = [
        ("POLYGON((500020 4250020, 500060 4250020, 500060 4250060, 500020 4250060, 500020 4250020))",
         ["Konut", 4.0, "Bitişik", "İyi", 120.0]),
        ("POLYGON((500120 4250020, 500170 4250020, 500170 4250070, 500120 4250070, 500120 4250020))",
         ["Ticaret", 3.0, "Ayrık", "Orta", 60.0]),
        ("POLYGON((500220 4250020, 500280 4250020, 500280 4250080, 500220 4250080, 500220 4250020))",
         ["Sanayi", 1.0, "Ayrık", "Orta", 0.0]),
    ]
    bldgs = mem_layer("Polygon", ["kullanim:string", "kat:double", "yd:string", "durum:string", "nufus:double"],
                      bldg_rows, "tekil_binalar")
    check(bldgs.isValid() and bldgs.featureCount() == 3, "Tekil yapılar katmanı oluşturuldu")

    # Doğal Eşikler
    dere = mem_layer("LineString", ["ad:string"],
                     [("LINESTRING(500050 4250000, 500050 4250300)", ["Buca Deresi"])], "dere")
    fay = mem_layer("LineString", ["ad:string"],
                    [("LINESTRING(500000 4250280, 500400 4250280)", ["Izmir Fayı"])], "fay")
    sit = mem_layer("Polygon", ["ad:string"],
                    [("POLYGON((500000 4250100, 500100 4250100, 500100 4250200, 500000 4250200, 500000 4250100))", ["Kentsel Sit"])], "sit")
    risk = mem_layer("Polygon", ["ad:string"],
                     [("POLYGON((500030 4250000, 500070 4250000, 500070 4250300, 500030 4250300, 500030 4250000))", ["Taskin Alani"])], "taskin_risk")
    donati = mem_layer("Point", ["ad:string"],
                       [("POINT(500150 4250150)", ["Hastane"])], "saglik_tesisi")

    check(all(lyr.isValid() for lyr in (dere, fay, sit, risk, donati)), "Tüm doğal eşik katmanları geçerli")

    # DEM Rasterı
    dem_path = os.path.join(tempfile.mkdtemp(), "dem_e2e.tif")
    make_dem_raster(dem_path, 5253)
    dem = QgsRasterLayer(dem_path, "dem_raster")
    check(dem.isValid(), "Sentetik DEM rasterı yüklendi (GDAL)")

    # Projeye katmanları ekle
    for lyr in (bnd, roads, blocks, bldgs, dere, fay, sit, risk, donati, dem):
        QgsProject.instance().addMapLayer(lyr)

    # 2. Analiz Çekirdeği (analiz.py) Doğrudan Fonksiyonel Testleri
    from AkilliBolgelemeAraci import analiz

    # A) filter_real_blocks refüj eleme testi
    raw_blk_geoms = analiz.read_geoms(blocks, QgsCoordinateReferenceSystem("EPSG:5253"))
    filtered_blocks, skipped_med = analiz.filter_real_blocks(raw_blk_geoms, "kullanim", filter_medians=True)
    check(skipped_med == 1, "filter_real_blocks: 1 adet ince refüj adacığı süzüldü (%d)" % skipped_med)
    check(len(filtered_blocks) == 8, "Geriye kalan 8 adet net imar adası korundu (%d)" % len(filtered_blocks))

    # B) build_cells_from_roads yol ağından hücre üretimi
    study_geom = bnd.getFeature(1).geometry()
    road_geoms = [g for _, g in analiz.read_geoms(roads, bnd.crs())]
    cells, absorbed = analiz.build_cells_from_roads(study_geom, road_geoms, filter_medians=True)
    check(len(cells) >= 6, "Yol ağından en az 6 hücre üretildi (%d hücre)" % len(cells))
    for c in cells:
        check(c.isGeosValid() and c.area() > 10.0, "Üretilen hücre geometrisi geçerli ve pozitif alanlı")

    # C) Hücre komşuluk grafı (build_adjacency)
    adj, cidx = analiz.build_adjacency(cells)
    check(len(adj) == len(cells), "Komşuluk grafı tüm hücreleri kapsıyor")
    check(any(len(nbs) > 0 for nbs in adj.values()), "Hücreler arasında bitişik komşuluk bağlantıları kuruldu")

    # D) Doğal Eşik Hesaplama (compute_extra)
    dere_geoms = [g for _, g in analiz.read_geoms(dere, bnd.crs())]
    dere_dists = analiz.compute_extra(cells, dere_geoms, "dist")
    check(len(dere_dists) == len(cells) and min(dere_dists) < 60.0, "Dereye en yakın mesafe doğru hesaplandı")

    sit_geoms = [g for _, g in analiz.read_geoms(sit, bnd.crs())]
    sit_shares = analiz.compute_extra(cells, sit_geoms, "share")
    check(max(sit_shares) > 0.4, "Sit alanı kesişim payı doğru hesaplandı (max=%.2f)" % max(sit_shares))

    # E) DEM Eğim Örnekleme (make_sampler & cell_slope)
    sampler = analiz.make_sampler(dem, bnd.crs())
    slopes = [analiz.cell_slope(cg, sampler, is_slope=False, step=10.0) for cg in cells]
    check(all(s is not None and s > 0.0 for s in slopes), "DEM rasterından tüm hücrelerin eğimleri başarıyla hesaplandı")

    # 3. Boru Hattı Uçtan Uca (run_pipeline)
    logs = []
    def log_cb(msg):
        logs.append(msg)
    progs = []
    def prog_cb(v):
        progs.append(v)

    P = {
        "work_crs": bnd.crs(),
        "boundary_layer": bnd,
        "road_layer": roads,
        "block_layer": blocks,
        "bldg_layer": bldgs,
        "fields": {"kat": "kat", "kullanim": "kullanim", "yd": "yd", "durum": "durum", "nufus": "nufus"},
        "bfields": {"kat": "kat", "kullanim": "kullanim", "yd": "yd", "durum": "durum", "nufus": "nufus"},
        "rfields": {"r_genislik": "genislik", "r_kaplama": "kaplama", "r_tur": "kademe"},
        "pop_cfg": {"mode": "auto", "manual_total": 5000, "per_bldg": 0},
        "extras": [
            {"name": "Dere", "role": "dere", "layer": dere},
            {"name": "Diri Fay", "role": "fay", "layer": fay},
            {"name": "Sit Alanı", "role": "sit", "layer": sit},
            {"name": "Afet Risk", "role": "risk", "layer": risk},
            {"name": "Sağlık Donatısı", "role": "donati", "layer": donati},
        ],
        "dem": dem,
        "dem_is_slope": False,
        "dem_step": 10.0,
        "K": 6,
        "w_lu": 1.2,
        "w_yapi": 1.0,
        "w_dogal": 1.0,
        "w_geo": 1.0,
        "cap_mult": 4.0,
        "grid_size": 100.0,
        "filter_medians": True,
        "use_excel": True,
    }

    res = analiz.run_pipeline(P, log_cb, prog_cb)
    check(res is not None, "run_pipeline başarıyla tamamlandı")
    check(len(res["zones"]) > 1, "Hedef alt bölgeler üretildi (üretilen bölge sayısı: %d)" % len(res["zones"]))
    check(100 in progs or len(progs) > 5, "İlerleme adımları kaydedildi")

    # Kural 1 & 5 Doğrulamaları
    zones = res["zones"]
    for z in zones:
        p = z.get("pay") or {}
        # Sanayi veya Tarım baskınsa yerleşik nüfus 0 olmalı!
        if p.get("sanayi", 0.0) >= 0.45 or p.get("tarim", 0.0) >= 0.70:
            check(z["nufus"] == 0.0, "Kural 1 Teyidi: Sanayi/Tarım bölgesinde (%s) nüfus = 0" % z["kod"])
        # Kural 5 Teyidi: Sınır ayrım gerekçesi en yüksek mutlak farkı oluşturan değişkenleri içermeli
        if z.get("ayrim_nedeni"):
            check("Komşu bölgelerden" in z["ayrim_nedeni"],
                  "Kural 5 Teyidi: '%s' için sınır ayrım gerekçesi metni üretildi" % z["kod"])

    # 4. Sonuç Katmanlarının Oluşturulması ve Semboloji (make_zone_layer & style_zone_layer)
    lyr_zones, records = analiz.make_zone_layer(res)
    check(lyr_zones.isValid(), "Alt bölge sonuç katmanı geçerli")
    check(lyr_zones.crs().authid() == "EPSG:5253", "Katman CRS'i EPSG:5253 olarak doğru atandı")
    check(lyr_zones.featureCount() == len(zones), "Katman özellik sayısı alt bölge sayısına eşit")
    check(lyr_zones.renderer().type() == "categorizedSymbol", "Kategorize semboloji stili uygulandı")
    check(lyr_zones.labelsEnabled(), "Alt bölge etiketleri başarıyla etkinleştirildi")

    # Alanların dolu ve temiz olduğunu kontrol et
    field_names = [f.name() for f in lyr_zones.fields()]
    check("Bolge_Kodu" in field_names and "Baskin_Karakter" in field_names, "Temel kimlik alanları mevcut")
    check("Bolgeleme_ve_Ayrim_Gerekcesi" in field_names, "Gerekçe alanı mevcut")
    check("Komsu_Bolgelerden_Ayrim_Nedeni" in field_names, "Komşu ayrım nedeni alanı mevcut")

    # Hücre katmanı kontrolü
    lyr_cells = analiz.make_cell_layer(res)
    check(lyr_cells.isValid() and lyr_cells.featureCount() == len(res["cells"]), "Hücre katmanı başarıyla üretildi")

    # 5. Arayüz Duman Testi (BolgelemeDialog)
    from AkilliBolgelemeAraci.bolgeleme_dialog import BolgelemeDialog
    fake_iface = FakeIface()
    dlg = BolgelemeDialog(fake_iface)
    check(dlg is not None, "BolgelemeDialog penceresi hatasız başlatıldı")

    # Projedeki katmanları otomatik eşleştir
    dlg.auto_populate_all_layers()
    check(dlg.cmb_boundary.currentLayer() == bnd, "Plan sınırı katmanı otomatik algılandı")
    check(dlg.cmb_road.currentLayer() == roads, "Yol ağı katmanı otomatik algılandı")
    check(dlg.cmb_block.currentLayer() == blocks, "İmar adaları katmanı otomatik algılandı")
    check(dlg.cmb_bldg.currentLayer() == bldgs, "Tekil yapılar katmanı otomatik algılandı")
    check(dlg.chk_use_bldg.isChecked(), "Tekil yapı stoku onay kutusu otomatik etkinleştirildi")
    check(dlg.tbl.rowCount() >= 3, "Doğal eşik katmanları otomatik tabloya eklendi (%d adet)" % dlg.tbl.rowCount())

    # Akıllı sütun eşleşmesi ve önizleme kontrolü
    match_kul = dlg.smart_match_field(blocks, ("kullanim", "fonksiyon"), want_numeric=False)
    check(match_kul == "kullanim", "Akıllı sütun eşleştirici 'kullanim' sütununu buldu")
    match_kat = dlg.smart_match_field(blocks, ("kat", "yukseklik"), want_numeric=True)
    check(match_kat == "kat", "Akıllı sütun eşleştirici 'kat' sütununu buldu")

    # Arayüz üzerinden çalıştırma (İleri Sentez Modu)
    dlg.spn_k.setValue(6)
    dlg.cmb_mode.setCurrentIndex(1)
    ok = dlg.run(interactive=False)
    check(ok, "Arayüz üzerinden İleri Sentez Modu (run) başarıyla tamamlandı")
    check(dlg.progress.value() == 100, "İlerleme çubuğu %100 tamamlandı")
    check("✔ Analiz tamamlandı" in dlg.txt.toPlainText(), "Günlük ekranına başarı raporu yazıldı")

    # Arayüz üzerinden çalıştırma (Standart Mod)
    dlg.cmb_mode.setCurrentIndex(0)
    ok_std = dlg.run(interactive=False)
    check(ok_std, "Arayüz üzerinden Standart Bölgeleme Modu (run) başarıyla tamamlandı")

    check(hasattr(dlg, "open_html_guide"), "open_html_guide metodu mevcut")
    check(os.path.exists(os.path.join(dlg.plugin_dir, "KULLANIM_KILAVUZU.html")),
          "Kapsamlı HTML metodoloji ve kullanım el kitabı mevcut")

    # CSV dışa aktarımı
    csv_temp = os.path.join(tempfile.mkdtemp(), "test_alt_bolgeler.csv")
    out_csv = dlg.export_csv(target_path=csv_temp)
    check(out_csv == csv_temp and os.path.exists(csv_temp), "CSV dışa aktarım dosyası oluşturuldu")
    with open(csv_temp, "r", encoding="utf-8-sig") as fh:
        reader = list(csv.reader(fh, delimiter=";"))
        check(len(reader) >= len(zones) + 1, "CSV dosyasında başlık ve veri satırları mevcut (%d satır)" % len(reader))
        header = reader[0]
        check("Bolge_Kodu" in header and "Komsu_Bolgelerden_Ayrim_Nedeni" in header,
              "CSV başlıkları açık Türkçe ve eksiksiz")
        check("Genel_Kirilganlik_Sinifi" in header or "Mudahale_Karari" in header,
              "İleri Mod: Kırılganlık ve Müdahale Kararları alanları mevcut")

    # Analiz İzleme Matrisi CSV testi
    matrix_temp = os.path.join(tempfile.mkdtemp(), "test_izleme_matrisi.csv")
    out_matrix = dlg.export_analysis_matrix(target_path=matrix_temp)
    check(out_matrix == matrix_temp and os.path.exists(matrix_temp), "Analiz İzleme ve Sentez Eşleştirme Matrisi CSV oluşturuldu")
    with open(matrix_temp, "r", encoding="utf-8-sig") as fh:
        m_reader = list(csv.reader(fh, delimiter=";"))
        check(len(m_reader) >= 4, "Analiz İzleme Matrisinde katmanlar listelendi (%d satır)" % len(m_reader))
        check("Analiz_Katmani_Adi" in m_reader[0] and "Sentezdeki_Rolu" in m_reader[0],
              "Analiz İzleme Matrisi sütun yapısı doğrulandı")
    dlg.close()

    # 6. Eklenti Yaşam Döngüsü Testi (classFactory / initGui / unload)
    import AkilliBolgelemeAraci
    plug = AkilliBolgelemeAraci.classFactory(fake_iface)
    check(plug is not None, "classFactory eklenti nesnesini üretti")
    plug.initGui()
    check(len(fake_iface.icons) == 1, "initGui: Araç çubuğuna eklenti ikonu eklendi")
    check(len(fake_iface.menus) == 1, "initGui: Vektör menüsüne eklenti menüsü eklendi")

    # Eklentiyi çalıştırıp pencereyi aç
    plug.run()
    check(plug.dialog is not None and plug.dialog.isVisible(), "plug.run(): Dialog oluşturuldu ve açıldı")

    # Eklentiyi kaldır (unload)
    plug.unload()
    check(len(fake_iface.icons) == 0, "unload(): Araç çubuğu ikonu temizlendi")
    check(len(fake_iface.menus) == 0, "unload(): Vektör menüsü temizlendi")
    check(plug.dialog is None, "unload(): Dialog kapatıldı ve temizlendi")

    print("\n" + "=" * 80)
    print("TEST SONUCU: %s (%d hata)" % ("BAŞARILI - TÜM E2E VE DUMAN TESTLERİ GEÇTİ" if not FAILS else "BAŞARISIZ", len(FAILS)))
    print("=" * 80)


try:
    main()
except Exception:
    traceback.print_exc()
    FAILS.append("beklenmeyen istisna")

APP.exitQgis() if not FAILS else None
sys.exit(1 if FAILS else 0)
